import {
  MainProgram,
  CommLogEntryData,
  AuthHeadersResponse,
  getAuthMethod,
  hasCertAuthConfig,
  hasOAuthOnPremConfig
} from "vscode-abap-remote-fs-sharedapi"
import { log, channel, rangeApi2Vsc } from "./lib"
import {
  AbapObjectDetail,
  Methods,
  StringWrapper,
  AbapObjectSource,
  urlFromPath,
  UriRequest,
  SearchProgress
} from "vscode-abap-remote-fs-sharedapi"
import { ExtensionContext, Uri, ProgressLocation, workspace, WorkspaceEdit } from "vscode"
import {
  LanguageClient,
  TransportKind,
  State,
  RevealOutputChannelOn
} from "vscode-languageclient/node"
export let client: LanguageClient
import { join } from "path"
import { FixProposal, Delta, LogData } from "abap-adt-api"
import { command, AbapFsCommands } from "./commands"
import { RemoteManager, formatKey } from "./config"
import { futureToken } from "./oauth"
import { getRoot, ADTSCHEME, uriRoot, getClient } from "./adt/conections"
import { CallLogger } from "./adt/adtCommLog"
import { isAbapFile } from "abapfs"
import { AbapObject } from "abapobject"
import { IncludeService, IncludeProvider } from "./adt/includes"
import * as R from "ramda"
import { funWindow as window } from "./services/funMessenger"
import { buildCookieHeaders, errorMessage } from "./auth/utils"

const uriErrors = new Map<string, boolean>()
const uriError = (uri: string) => new Error(`File not found:${uri}`)

export async function vsCodeUri(
  confKey: string,
  uri: string,
  mainInclude: boolean,
  cacheErrors = false
): Promise<string> {
  const isContextualInclude = /\/source\/main/i.test(uri)
  const normalizedUri = isContextualInclude
    ? uri.replace(/\/source\/main(?:[?#].*)?$/i, "") || uri
    : uri
  const effectiveMain = mainInclude || isContextualInclude

  const key = `${confKey}_${normalizedUri}_${effectiveMain}`
  if (cacheErrors && uriErrors.get(key)) throw uriError(uri)

  const tryUris = [normalizedUri, uri]
  const root = getRoot(confKey)
  let lastError: unknown

  for (const u of tryUris) {
    try {
      const hit = await root.findByAdtUri(u, effectiveMain)
      if (hit) return urlFromPath(confKey, hit.path)
    } catch (error) {
      lastError = error
    }
  }

  if (cacheErrors) uriErrors.set(key, true)
  throw lastError || uriError(uri)
}

async function getVSCodeUri({ confKey, uri, mainInclude }: UriRequest): Promise<StringWrapper> {
  const s = await vsCodeUri(confKey, uri, mainInclude)
  return { s }
}

export function findEditor(url: string) {
  return window.visibleTextEditors.find(
    e => e.document.uri.scheme === ADTSCHEME && e.document.uri.toString() === url
  )
}
async function readEditorObjectSource(url: string) {
  const current = findEditor(url)
  const source: AbapObjectSource = { source: "", url }
  if (current) source.source = current.document.getText()
  return source
}

async function readObjectSource(uri: string) {
  const source = await readEditorObjectSource(uri)
  if (source.source) return source

  const url = Uri.parse(uri)
  const root = uriRoot(url)
  const file = (await root.getNodeAsync(url.path)) || {}
  if (!isAbapFile(file)) throw new Error(`File not found:${uri}`)
  const code = await file.read()
  return { source: code, url: url.toString() }
}

function objectDetail(obj: AbapObject, mainProgram?: string) {
  if (!obj) return
  const detail: AbapObjectDetail = {
    url: obj.path,
    mainUrl: obj.contentsPath(),
    mainProgram,
    type: obj.type,
    name: obj.name
  }
  return detail
}

async function objectDetailFromUrl(url: string) {
  const uri = Uri.parse(url)
  const root = uriRoot(uri)
  const obj = await root.getNodeAsync(uri.path)
  if (!isAbapFile(obj)) throw new Error("not found") // TODO error

  // Load structure if not already loaded (required for contentsPath())
  if (!obj.object.structure) {
    await obj.object.loadStructure()
  }

  let mainProgram
  if (obj.object.type === "PROG/I")
    mainProgram = IncludeService.get(uri.authority).current(uri.path)
  return objectDetail(obj.object, mainProgram?.["adtcore:uri"])
}

export async function configFromKey(connId: string) {
  const connection = await RemoteManager.get().byIdAsync(connId)
  if (!connection) return undefined
  const { sapGui, ...cfg } = connection
  return cfg
}
async function getToken(connId: string) {
  return futureToken(formatKey(connId))
}

/** Provide auth headers (cookies etc.) to the language server for non-basic auth. */
async function getAuthHeaders(connId: string): Promise<AuthHeadersResponse | undefined> {
  connId = formatKey(connId)
  const conn = await RemoteManager.get().byIdAsync(connId)
  if (!conn) return undefined
  const authMethod = getAuthMethod(conn)
  switch (authMethod) {
    case "kerberos": {
      const { log: libLog } = await import("./lib")
      try {
        libLog.debug(`[langClient] getAuthHeaders: re-negotiating kerberos for ${connId}`)
        const { refreshKerberosAuth } = await import("./auth/kerberos")
        const result = await refreshKerberosAuth(
          connId,
          conn.kerberosAuth,
          conn.url,
          conn.client,
          !!conn.allowSelfSigned
        )
        libLog.debug(`[langClient] getAuthHeaders: kerberos refresh success for ${connId}`)
        return result.headers ? { httpHeaders: result.headers } : undefined
      } catch (e) {
        libLog.debug(
          `[langClient] getAuthHeaders: kerberos re-negotiation failed for ${connId}: ${errorMessage(e)}`
        )
        const { getKerberosCookies } = await import("./auth/kerberos")
        const cookies = await getKerberosCookies(connId)
        libLog.debug(
          `[langClient] getAuthHeaders: falling back to ${cookies.length} cached cookies for ${connId}`
        )
        const httpHeaders = buildCookieHeaders(cookies)
        return httpHeaders ? { httpHeaders } : undefined
      }
    }
    case "browser_sso": {
      const { log: libLog } = await import("./lib")
      try {
        libLog.debug(`[langClient] getAuthHeaders: resolving browser_sso cookies for ${connId}`)
        const { buildBrowserSsoAuth, getSsoCookies } = await import("./auth/browserSso")
        const result = await buildBrowserSsoAuth(connId, conn.url, conn.client)
        if (result.headers) {
          libLog.debug(`[langClient] getAuthHeaders: browser_sso capture resolved for ${connId}`)
          return { httpHeaders: result.headers }
        }

        const cookies = await getSsoCookies(connId)
        const httpHeaders = buildCookieHeaders(cookies)
        return httpHeaders ? { httpHeaders } : undefined
      } catch (e) {
        libLog.debug(
          `[langClient] getAuthHeaders: browser_sso capture failed for ${connId}: ${errorMessage(e)}`
        )
        const { getSsoCookies } = await import("./auth/browserSso")
        const cookies = await getSsoCookies(connId)
        const httpHeaders = buildCookieHeaders(cookies)
        return httpHeaders ? { httpHeaders } : undefined
      }
    }
    case "cert": {
      const { log: libLog } = await import("./lib")
      if (!hasCertAuthConfig(conn)) {
        libLog.debug(`[langClient] getAuthHeaders: cert auth config missing for ${connId}`)
        return undefined
      }
      libLog.debug(`[langClient] getAuthHeaders: returning cert paths for ${connId}`)
      const { getCertPassphrase } = await import("./auth/certificate")
      const passphrase = await getCertPassphrase(connId)
      return {
        certAuth: {
          certPath: conn.certAuth.certPath,
          keyPath: conn.certAuth.keyPath,
          caPath: conn.certAuth.caPath || undefined,
          passphrase: passphrase || undefined
        }
      }
    }
    case "oauth_onprem": {
      const { log: libLog } = await import("./lib")
      libLog.debug(`[langClient] getAuthHeaders: fetching oauth_onprem token for ${connId}`)
      const { buildOAuthOnPremAuth } = await import("./auth/oauthOnPrem")
      if (!hasOAuthOnPremConfig(conn)) {
        libLog.debug(`[langClient] getAuthHeaders: oauth_onprem config missing for ${connId}`)
        return undefined
      }
      try {
        const result = await buildOAuthOnPremAuth(
          connId,
          conn.url,
          conn.client,
          conn.oauthOnPrem,
          !!conn.allowSelfSigned
        )
        if (typeof result.passwordOrFetcher === "function") {
          const token = await result.passwordOrFetcher()
          libLog.debug(`[langClient] getAuthHeaders: returning Bearer token for ${connId}`)
          return { httpHeaders: { Authorization: `Bearer ${token}` } }
        }
      } catch (e) {
        libLog.debug(
          `[langClient] getAuthHeaders: oauth_onprem token fetch failed for ${connId}: ${errorMessage(e)}`
        )
      }
      return undefined
    }
    default:
      return undefined
  }
}

let setProgress: ((prog: SearchProgress) => void) | undefined
async function setSearchProgress(searchProg: SearchProgress) {
  if (setProgress) setProgress(searchProg)
  else if (!searchProg.ended) {
    window.withProgress(
      {
        location: ProgressLocation.Notification,
        cancellable: true,
        title: "Where used list in progress - "
      },
      (progress, token) =>
        new Promise((resolve, reject) => {
          let current = 0
          token.onCancellationRequested(async () => {
            setProgress = undefined
            await client.sendRequest(Methods.cancelSearch)
            resolve(undefined)
          })
          setProgress = (s: SearchProgress) => {
            if (s.ended) {
              progress.report({ increment: 100, message: `Search completed,${s.hits} found` })
              setProgress = undefined
              resolve(undefined)
              return
            }
            progress.report({
              increment: s.progress - current,
              message: `Searching usage references, ${s.hits} hits found so far`
            })
            current = s.progress
          }
        })
    )
  }
}

async function includeChanged(prog: MainProgram) {
  await client.sendRequest(Methods.updateMainProgram, prog)
}

// Trigger syntax check for a specific URI (used when switching editors)
export async function triggerSyntaxCheck(uri: string) {
  if (client && client.state === State.Running) {
    await client.sendRequest(Methods.triggerSyntaxCheck, uri)
  }
}

const hidrateLogData = (entry: LogData): LogData => ({
  ...entry,
  startTime: new Date(entry.startTime)
})

export async function startLanguageClient(context: ExtensionContext) {
  const module = context.asAbsolutePath(join("server", "dist", "server.js"))
  const transport = TransportKind.ipc
  const options = { execArgv: ["--nolazy", "--inspect=6010"] }
  // log("creating language client...")

  client = new LanguageClient(
    "ABAPFS_LC",
    "Abap FS Language client",
    {
      run: { module, transport },
      debug: { module, transport, options }
    },
    {
      documentSelector: [
        { language: "abap", scheme: ADTSCHEME },
        { language: "abap_cds", scheme: ADTSCHEME }
      ],
      outputChannel: channel,
      revealOutputChannelOn: RevealOutputChannelOn.Warn
    }
  )

  IncludeProvider.get().onDidSelectInclude(includeChanged)

  client.onDidChangeState(e => {
    if (e.newState === State.Running) {
      client.onRequest(Methods.readConfiguration, configFromKey)
      client.onRequest(Methods.objectDetails, objectDetailFromUrl)
      client.onRequest(Methods.readEditorObjectSource, readEditorObjectSource)
      client.onRequest(Methods.readObjectSourceOrMain, readObjectSource)
      client.onRequest(Methods.vsUri, getVSCodeUri)
      client.onRequest(Methods.setSearchProgress, setSearchProgress)
      client.onRequest(Methods.getToken, getToken)
      client.onRequest(Methods.getAuthHeaders, getAuthHeaders)
      client.onNotification(Methods.commLogEntry, (entry: CommLogEntryData) =>
        CallLogger.get(entry.connId)?.add(hidrateLogData(entry.logData))
      )
    }
  })
  client.start()
}

export class LanguageCommands {
  public static start(context: ExtensionContext) {
    command(AbapFsCommands.quickfix)(this, "applyQuickFix")
    return startLanguageClient(context)
  }

  public static async applyQuickFix(proposal: FixProposal, uri: string) {
    const u = Uri.parse(uri)
    const cl = getClient(u.authority)

    const source = await readEditorObjectSource(uri)

    const deltaLine = (d: Delta) => d.range.start.line
    const sortDelta = R.sortWith<Delta>([R.ascend(R.prop("uri")), R.descend(deltaLine)])

    const deltas = await cl.fixEdits(proposal, source.source).then(sortDelta)
    if (!deltas || deltas.length === 0) return
    const we = new WorkspaceEdit()
    const touched = new Set<string>()

    for (const d of deltas) {
      const ur = await getVSCodeUri({
        uri: d.uri,
        confKey: u.authority,
        mainInclude: true
      })
      if (!ur.s) continue
      touched.add(ur.s)
      const range = rangeApi2Vsc(d.range)
      we.replace(Uri.parse(ur.s), range, d.content)
    }
    await workspace.applyEdit(we)
  }
}
