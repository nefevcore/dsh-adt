import { TransportsProvider } from "./views/transports"
import { FavouritesProvider } from "./views/favourites"
import { atcProvider, registerSCIDecorator } from "./views/abaptestcockpit"
import { FsProvider } from "./fs/FsProvider"
import { AbapFileDecorationProvider } from "./fs/AbapFileDecorationProvider"
import { workspace, ExtensionContext, languages, commands } from "vscode"
import {
  activeTextEditorChangedListener,
  documentChangedListener,
  documentClosedListener,
  documentWillSave,
  restoreLocks
} from "./listeners"
import { PasswordVault, log } from "./lib"
import { LanguageCommands } from "./langClient"
import { registerRevisionModel, AbapRevisionLens } from "./scm/abaprevisions"
import { ClassHierarchyLensProvider } from "./adt/classhierarchy"
import { abapGitProvider } from "./views/abapgit"
import { loadTokens, clearTokens } from "./oauth"
import { registerAbapGit } from "./scm/abapGit"
import { AbapFsApi, api } from "./api"
import { ADTSCHEME, disconnect, hasLocks } from "./adt/conections"
import { MessagesProvider } from "./editors/messages"
import { IncludeProvider } from "./adt/includes"
import { registerCommands } from "./commands/register"
import { HttpProvider } from "./editors/httpprovider"
import { dumpProvider } from "./views/dumps/dumps"
import { registerAbapDebugger } from "./adt/debugger"
import { ATCDocumentation } from "./views/abaptestcockpit/documentation"
import { CommLogPanel } from "./adt/adtCommLog"
import { tracesProvider } from "./views/traces"
import { s4hProvider } from "./views/s4hanaReadiness"
import { FeedStateManager } from "./services/feeds/feedStateManager"
import { FeedPollingService } from "./services/feeds/feedPollingService"
import { initializeFeedInboxProvider } from "./views/feeds/feedInboxView"
import { setContext } from "./context"
import { AbapHoverProviderV2 } from "./providers/hoverProvider"
import { AbapDocumentSymbolProvider } from "./providers/abapDocumentSymbolProvider"
import { registerAllTools } from "./services/lm-tools"
import { registerTestingFeatures } from "./services/testing/activation"
import { registerCleanerCommands, setupCleanerContextMonitoring } from "./services/cleanerCommands"
import { TelemetryService, logTelemetry } from "./services/telemetry"
import { AppInsightsService } from "./services/appInsightsService"
import { MermaidWebviewManager } from "./services/MermaidWebviewManager"
import { DiagramWebviewManager } from "./services/DiagramWebviewManager"
import { SapSystemValidator } from "./services/sapSystemValidator"
import { listAdtFeedsCommand } from "./commands/listAdtFeeds"
import { validateSubagentsOnStartup } from "./services/lm-tools/subagentConfigTool"
import { initializeMcpServer, startMcpServerCommand } from "./services/mcpServer"
import { registerChatTools } from "./adt/ai/tools"
import { initializeEnhancementDecorations } from "./views/enhancementDecorations"
import { initializeBlameGutter } from "./views/blameGutter"
import { clearSystemInfoCache } from "./services/sapSystemInfo"
import { HeartbeatWatchlist } from "./services/heartbeat/heartbeatWatchlist"
import { RapGeneratorPanel } from "./views/rapGenerator/rapGeneratorView"
import { visualizeDependencyGraph } from "./services/dependencyGraph"
import { checkUpgradeNotification } from "./services/upgradeNotification"
import { registerAbapRepl } from "./repl"
import { registerAbapNotebooks } from "./notebooks"
import { showWelcomeWalkthrough } from "./services/walkthroughService"
import { registerVirtualToolsFixOnConnect } from "./services/virtualToolsFix"
import { ObjectPropertyProvider } from "./views/objectProperties"
import { ObjectSearchViewProvider } from "./views/objectSearchView"
import { funWindow as window } from "./services/funMessenger"
import { initializeReviewPrompt } from "./services/reviewPrompt"
import { registerBdefType } from "./adt/operations/BdefCreator"

// Import commands to ensure @command decorators are executed
import "./commands"

export let context: ExtensionContext

// Feed polling service instance (module-level for deactivation)
let feedPollingServiceInstance: FeedPollingService | undefined

function checkPasswordsInSettings() {
  setTimeout(
    () => {
      const remotes = workspace.getConfiguration("abapfs")?.get<Record<string, any>>("remote")
      if (!remotes) return
      const systemsWithPasswords = Object.entries(remotes)
        .filter(([_, cfg]) => typeof cfg?.password === "string" && cfg.password.trim().length > 0)
        .map(([name]) => name)
      if (systemsWithPasswords.length > 0) {
        window.showWarningMessage(
          `Security risk: ${systemsWithPasswords.length} SAP connection(s) have passwords stored in plain text settings (${systemsWithPasswords.join(", ")}). ` +
            `Remove them from your settings JSON — ABAP FS will prompt for your password securely when connecting.`
        )
      }
    },
    10 * 60 * 1000
  )
}

export async function activate(ctx: ExtensionContext): Promise<AbapFsApi> {
  context = ctx
  const startTime = new Date().getTime()
  log("🚀 Buckle up buttercup, ABAP FS is waking up from its slumber...")

  // Register additional creatable types
  registerBdefType()

  // 📊 Initialize Telemetry Services in the background to avoid blocking activation
  setImmediate(() => {
    try {
      TelemetryService.initialize(ctx)
      log("📊 Local Telemetry Service initialized")

      // Initialize App Insights
      AppInsightsService.getInstance(ctx)
      log("📊 App Insights initialization started in background")
    } catch (error) {
      log(`❌ Telemetry Services initialization failed: ${error}`)
    }
  })

  // 🔐 Initialize SAP System Validator FIRST (before any client connections)
  try {
    log("🔐 SAP System Validator entering the chat... *cracks knuckles*")
    const validator = SapSystemValidator.getInstance()
    await validator.initialize()
    log("✅ SAP System Validator ready to judge your systems mercilessly")
  } catch (error) {
    log(`❌ SAP System Validator threw a tantrum: ${error} (it's fine, everything is fine 🔥)`)
    // Continue activation even if validator fails - will block all connections except backup whitelist if configured
  }

  new PasswordVault(ctx)
  loadTokens()
  clearTokens()
  checkPasswordsInSettings()
  const sub = context.subscriptions

  // 🧠 ABAP Intelligence Integration - Start
  try {
    log("🧠 ABAP Intelligence features booting up... *elevator music plays*")

    // Initialize hover provider
    const hoverProvider = new AbapHoverProviderV2(log)

    // Register language providers for ABAP
    const abapSelector = { language: "abap", scheme: "file" }
    const adtSelector = { language: "abap", scheme: ADTSCHEME }
    const cdsSelector = { language: "abap_cds", scheme: ADTSCHEME }

    sub.push(
      languages.registerHoverProvider([abapSelector, adtSelector, cdsSelector], hoverProvider)
    )
    sub.push(
      languages.registerDocumentSymbolProvider([adtSelector], new AbapDocumentSymbolProvider())
    )

    log("✅ ABAP Hover Provider ready to whisper sweet nothings about your code")

    // Register List ADT Feeds command
    context.subscriptions.push(commands.registerCommand("abapfs.listAdtFeeds", listAdtFeedsCommand))

    const { copilotLogger } = require("./services/abapCopilotLogger")
    copilotLogger.info(
      "Extension",
      "ABAP FS logging initialized - Ready to document your debugging adventures 🗺️"
    )

    // Initialize the MermaidWebviewManager singleton
    MermaidWebviewManager.initialize(context.extensionUri)

    // Initialize the DiagramWebviewManager singleton
    DiagramWebviewManager.initialize(context.extensionUri)
    log("🧜‍♀️ Mermaid Webview Manager ready to make your diagrams prettier than your code")

    // Register Language Model Tools
    await registerAllTools(context)

    // Register SAP UI testing features (dormant until a test folder is configured)
    registerTestingFeatures(context)

    // Register ABAP Cleaner feature
    registerCleanerCommands(context)
    setupCleanerContextMonitoring(context)

    // Initialize ABAP REPL
    registerAbapRepl(context)

    // Initialize SAP Data Workbook (.sapwb)
    registerAbapNotebooks(context)

    sub.push(
      commands.registerCommand("abapfs.startMcpServer", () => startMcpServerCommand(context))
    )
    // Delay validation so Copilot's chat models finish loading; otherwise
    // `selectChatModels({})` returns an empty list and triggers a false AUTO-DISABLED.
    setTimeout(() => validateSubagentsOnStartup(context), 10000)
    log("🚀 ABAP FS services are GO! Houston, we have liftoff! 🌙")
    // ABAP FS Integration - End
  } catch (error) {
    log(`❌ ABAP Intelligence features had an existential crisis: ${error}`)
    console.error("❌ Failed to activate ABAP Intelligence features:", error)
    window.showErrorMessage(`Failed to activate ABAP Intelligence features: ${error}`)
  }
  // ABAP Intelligence Integration - End

  // register the filesystem type
  sub.push(
    workspace.registerFileSystemProvider(ADTSCHEME, FsProvider.get(ctx), {
      isCaseSensitive: true
    })
  )

  // dynamic tooltips for adt:// tree items (uses whatever metadata is loaded)
  const abapFileDecorationProvider = new AbapFileDecorationProvider()
  sub.push(abapFileDecorationProvider)
  sub.push(window.registerFileDecorationProvider(abapFileDecorationProvider))

  // change document listener, for locking
  sub.push(workspace.onDidChangeTextDocument(documentChangedListener))
  sub.push(workspace.onWillSaveTextDocument(documentWillSave))
  // closed document listener, for locking
  sub.push(workspace.onDidCloseTextDocument(documentClosedListener))
  // Editor changed listener, updates context and icons
  sub.push(window.onDidChangeActiveTextEditor(activeTextEditorChangedListener))

  registerRevisionModel(context)

  const fav = FavouritesProvider.get()
  fav.storagePath = context.globalStoragePath
  const objectPropertyProvider = ObjectPropertyProvider.get()
  sub.push(window.registerTreeDataProvider("abapfs.favorites", fav))
  sub.push(window.registerTreeDataProvider("abapfs.transports", TransportsProvider.get()))
  sub.push(window.registerTreeDataProvider("abapfs.abapgit", abapGitProvider))
  sub.push(window.registerTreeDataProvider("abapfs.dumps", dumpProvider))
  sub.push(window.registerTreeDataProvider("abapfs.atcFinds", atcProvider))
  sub.push(window.registerTreeDataProvider("abapfs.traces", tracesProvider))
  sub.push(window.registerTreeDataProvider("abapfs.s4hReadiness", s4hProvider))
  sub.push(window.registerWebviewViewProvider(RapGeneratorPanel.viewType, RapGeneratorPanel.get()))
  const objectPropertyView = window.createTreeView("abapfs.objectProperty", {
    treeDataProvider: objectPropertyProvider,
    showCollapseAll: false,
    canSelectMany: false
  })
  objectPropertyProvider.bindView(objectPropertyView)
  sub.push(objectPropertyProvider)
  sub.push(objectPropertyView)

  // Initialize Feed State Manager and Polling Service
  const feedStateManager = new FeedStateManager(context)
  feedPollingServiceInstance = new FeedPollingService(context, feedStateManager)
  const feedInboxProvider = initializeFeedInboxProvider(feedStateManager)
  sub.push(window.registerTreeDataProvider("abapfs.feedInbox", feedInboxProvider))

  // Connect polling service to tree view for refresh
  feedPollingServiceInstance.setOnEntriesChanged(() => {
    feedInboxProvider.refresh()
  })

  // Start feed polling service
  await feedPollingServiceInstance.start()

  // Register feed inbox commands
  sub.push(
    commands.registerCommand("abapfs.refreshFeedInbox", () => {
      feedInboxProvider.refresh()
    })
  )

  sub.push(
    commands.registerCommand(
      "abapfs.showFeedInbox",
      (options?: { systemId?: string; feedTitle?: string }) => {
        feedInboxProvider.showFeedInbox(options)
      }
    )
  )

  sub.push(
    commands.registerCommand("abapfs.markAllFeedsRead", () => {
      feedInboxProvider.markAllAsRead()
    })
  )

  sub.push(
    commands.registerCommand("abapfs.markFeedFolderRead", (node: any) => {
      feedInboxProvider.markFeedFolderAsRead(node)
    })
  )

  sub.push(
    commands.registerCommand("abapfs.deleteFeedEntry", (node: any) => {
      feedInboxProvider.deleteFeedEntry(node)
    })
  )

  sub.push(
    commands.registerCommand("abapfs.clearFeedFolder", (node: any) => {
      feedInboxProvider.clearFeedFolder(node)
    })
  )

  sub.push(
    commands.registerCommand("abapfs.viewFeedEntry", (node: any) => {
      feedInboxProvider.viewFeedEntry(node)
    })
  )
  sub.push(
    languages.registerCodeLensProvider(
      { language: "abap", scheme: ADTSCHEME },
      ClassHierarchyLensProvider.get()
    )
  )
  sub.push(
    languages.registerCodeLensProvider(
      { language: "abap", scheme: ADTSCHEME },
      AbapRevisionLens.get()
    )
  )

  sub.push(
    languages.registerCodeLensProvider(
      { language: "abap", scheme: ADTSCHEME },
      IncludeProvider.get()
    )
  )

  sub.push(window.registerWebviewViewProvider(ATCDocumentation.viewType, ATCDocumentation.get()))
  sub.push(window.registerWebviewViewProvider(CommLogPanel.viewType, CommLogPanel.get()))
  sub.push(
    window.registerWebviewViewProvider(
      ObjectSearchViewProvider.viewType,
      ObjectSearchViewProvider.get()
    )
  )

  sub.push(MessagesProvider.register(context))
  sub.push(HttpProvider.register(context))
  registerAbapDebugger(context)

  LanguageCommands.start(context)

  setContext("abapfs:extensionActive", true)
  setContext(
    "abapfs:noSapConnected",
    !(workspace.workspaceFolders?.some(f => f.uri.scheme === ADTSCHEME) ?? false)
  )
  sub.push(
    workspace.onDidChangeWorkspaceFolders(() => {
      setContext(
        "abapfs:noSapConnected",
        !(workspace.workspaceFolders?.some(f => f.uri.scheme === ADTSCHEME) ?? false)
      )
    })
  )
  restoreLocks()
  registerAbapGit(context)

  registerCommands(context)

  // 📊 Register Dependency Graph Command
  try {
    context.subscriptions.push(
      commands.registerCommand("abapfs.visualizeDependencyGraph", () => {
        logTelemetry("command_dependency_graph_called")
        return visualizeDependencyGraph()
      })
    )
    log("📊 Dependency graph ready to expose your spaghetti architecture 🍝")
  } catch (error) {
    log(`⚠️ Dependency graph said 'I can\'t even': ${error}`)
  }

  // 💓 Register Heartbeat Commands
  try {
    context.subscriptions.push(
      commands.registerCommand("abapfs.openHeartbeatJson", async () => {
        logTelemetry("command_open_heartbeat_json_called")
        const filePath = HeartbeatWatchlist.getFilePath()
        if (filePath) {
          const doc = await workspace.openTextDocument(filePath)
          await window.showTextDocument(doc)
        } else {
          window.showWarningMessage(
            "No heartbeat.json file found. Open a folder-based workspace first."
          )
        }
      })
    )
    log("💓 Heartbeat watchlist command registered - Your personal SAP nanny awaits")
  } catch (error) {
    log(`⚠️ Heartbeat command registration failed: ${error}`)
  }

  registerSCIDecorator(context)

  // 🎯 Initialize Enhancement Decorations
  try {
    initializeEnhancementDecorations(context)
    log("🎯 Enhancement decorations initialized - Making your code look fancy since 2024")
  } catch (error) {
    log(
      `⚠️ Enhancement decorations refused to cooperate: ${error} (they're artists, they're temperamental)`
    )
  }

  // 📋 Initialize Blame Gutter
  try {
    initializeBlameGutter(context)
    log("📋 Blame gutter initialized — Ready to point fingers at your colleagues' code")
  } catch (error) {
    log(`⚠️ Blame gutter initialization failed: ${error}`)
  }
  registerChatTools(context)

  // Walkthrough helper: open Copilot chat with a pre-filled query
  sub.push(
    commands.registerCommand("abapfs.openChatWithQuery", (query: string) => {
      commands.executeCommand("workbench.action.chat.open", {
        query,
        isPartialQuery: true
      })
    })
  )

  // Check for v1 → v2 upgrade and show notification + status bar hint
  checkUpgradeNotification(context)

  // Show Getting Started walkthrough on first install
  showWelcomeWalkthrough(context)

  // Initialize review prompt (rate on Marketplace after sustained usage)
  try {
    initializeReviewPrompt(context)
  } catch {
    // Non-critical — never break extension activation
  }

  // Register virtual tools fix — fires once on first SAP connection, not at activation
  registerVirtualToolsFixOnConnect(context)

  // Initialize MCP Server LAST so that all LM tools, context keys, and providers
  // are fully registered before any waiting MCP client (Claude Code, Cursor, ...)
  // can connect and enumerate vscode.lm.tools.
  try {
    await initializeMcpServer(context)
  } catch (error) {
    log(`⚠️ MCP server initialization failed: ${error}`)
  }

  const elapsed = new Date().getTime() - startTime
  log.debug(`Activated,pid=${process.pid}, activation time(ms):${elapsed}`)
  return api
}

// this method is called when your extension is deactivated
// it's important to kill these sessions as there might be an open process on the abap side
// most commonly because of locked sources.
// Locks will not be released until either explicitly closed or the session is terminates
// an open session can leave sources locked without any UI able to release them (except SM12 and the like)
export async function deactivate() {
  if (hasLocks())
    window.showInformationMessage(
      "Locks will be dropped now. If the relevant editors are still open they will be restored later"
    )
  setContext("abapfs:extensionActive", false)

  // Stop feed polling service
  if (feedPollingServiceInstance) {
    feedPollingServiceInstance.stop()
    log("📰 Feed polling service stopped - No more news is good news, right?")
  }

  // Clear SAP system info cache
  try {
    clearSystemInfoCache()
    log("🧹 SAP system info cache cleared - It's like it never happened *whistles innocently*")
  } catch (e) {
    // Ignore - service may not be loaded
  }

  return disconnect()
}
