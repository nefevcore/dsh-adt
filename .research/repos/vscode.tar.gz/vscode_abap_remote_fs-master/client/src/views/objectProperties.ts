import {
  commands,
  Event,
  EventEmitter,
  ThemeIcon,
  TreeDataProvider,
  TreeItem,
  TreeItemCheckboxState,
  TreeItemCollapsibleState,
  TreeView,
  Uri,
  workspace,
  Disposable
} from "vscode"
import { TransportInfo, MainInclude, Revision } from "abap-adt-api"
import { isAbapStat } from "abapfs"
import { LockStatus } from "abapfs/out/lockObject"
import { AbapObject } from "abapobject"
import { AbapFsCommands } from "../commands"
import { getClient, uriRoot, abapUri } from "../adt/conections"
import { caughtToString, log } from "../lib"
import { AbapRevisionService, revLabel } from "../scm/abaprevisions/abaprevisionservice"
import { revisionUri } from "../scm/abaprevisions/documentprovider"
import { readTransports } from "./transports"
import { getCombinedObjectTypeLabel } from "./objectTypeLabels"
import { funWindow as window } from "../services/funMessenger"

const OBJECT_PROPERTY_COMPARE_COMMAND = "abapfs.objectPropertyCompareSelectedInline"

type PropertyNode =
  | PropertyValueItem
  | TransportPropertyItem
  | TransportRequestChildItem
  | HistoryPropertyItem
  | CompareSelectedHistoryItem
  | RevisionChildItem

// --- Simple TTL cache ---

class TtlCache<V> {
  private store = new Map<string, { value: V; expiresAt: number }>()
  constructor(private ttlMs: number) {}

  get(key: string): V | undefined {
    const entry = this.store.get(key)
    if (entry && entry.expiresAt > Date.now()) return entry.value
    this.store.delete(key)
    return undefined
  }

  set(key: string, value: V) {
    this.store.set(key, { value, expiresAt: Date.now() + this.ttlMs })
  }

  delete(key: string) {
    this.store.delete(key)
  }
  clear() {
    this.store.clear()
  }
}

// --- Tree items ---

class PropertyValueItem extends TreeItem {
  constructor(
    public readonly key: string,
    public readonly value: string,
    public readonly copyValue: string = value,
    icon = "symbol-property"
  ) {
    super(key, TreeItemCollapsibleState.None)
    this.description = value || "-"
    this.tooltip = `${key}: ${value || "-"}`
    this.iconPath = new ThemeIcon(icon)
    this.contextValue = "objectPropertyValue"
  }
}

class TransportRequestChildItem extends TreeItem {
  public readonly connId: string
  public readonly task: Record<string, string>

  constructor(connId: string, transportNumber: string, description: string) {
    super(transportNumber, TreeItemCollapsibleState.None)
    this.connId = connId
    this.description = description || "-"
    this.tooltip = description ? `${transportNumber}: ${description}` : transportNumber
    this.iconPath = new ThemeIcon("package")
    this.contextValue = "objectPropertyValue"
    this.task = {
      "tm:number": transportNumber,
      "tm:uri": transportRequestUri(transportNumber)
    }
    this.command = {
      title: "Open transport in GUI",
      command: AbapFsCommands.transportOpenGui,
      arguments: [this]
    }
  }
}

class TransportPropertyItem extends PropertyValueItem {
  private static readonly transportCache = new TtlCache<Promise<any>>(30000)
  private static readonly childrenCache = new TtlCache<PropertyNode[]>(30000)

  public readonly connId: string
  public readonly user: string
  public readonly task: Record<string, string>

  public static clearTransportCache() {
    this.transportCache.clear()
    this.childrenCache.clear()
  }

  private get cacheKey() {
    return `${this.connId}:${this.user.toUpperCase()}:${this.task["tm:number"]}`
  }

  private static readTransportsCached(connId: string, user: string) {
    const key = `${connId}:${user.toUpperCase()}`
    const cached = this.transportCache.get(key)
    if (cached) return cached

    const promise = readTransports(connId, user).catch(error => {
      this.transportCache.delete(key)
      throw error
    })
    this.transportCache.set(key, promise)
    return promise
  }

  constructor(
    label: string,
    connId: string,
    user: string,
    transportNumber: string,
    transportUri: string
  ) {
    super("Transport", label, transportNumber, "package")
    this.connId = connId
    this.user = user
    this.task = {
      "tm:number": transportNumber,
      "tm:uri": transportUri
    }
    this.contextValue = "objectPropertyTransport"
    this.collapsibleState = TreeItemCollapsibleState.Collapsed
    this.command = {
      title: "Open transport in GUI",
      command: AbapFsCommands.transportOpenGui,
      arguments: [this]
    }
  }

  public async getChildren(): Promise<PropertyNode[]> {
    const cached = TransportPropertyItem.childrenCache.get(this.cacheKey)
    if (cached) return cached

    try {
      const transports = await TransportPropertyItem.readTransportsCached(this.connId, this.user)
      const context = findTransportContext(transports, this.task["tm:number"])
      const children: PropertyNode[] = (context?.tasks ?? []).map(
        (task: Record<string, any>) =>
          new TransportRequestChildItem(this.connId, task["tm:number"], task["tm:desc"] || "")
      )
      TransportPropertyItem.childrenCache.set(this.cacheKey, children)
      return children
    } catch {
      return [new PropertyValueItem("Transport details", "Unable to load subtasks", "", "warning")]
    }
  }
}

class RevisionChildItem extends TreeItem {
  public readonly revision: Revision
  public readonly revisionKey: string
  public readonly displayIndex: number

  constructor(
    private readonly uri: Uri,
    revision: Revision,
    index: number,
    checked: boolean,
    forceInactive = false
  ) {
    super(revisionLabel(revision, index), TreeItemCollapsibleState.None)
    this.revision = revision
    this.revisionKey = revision.uri || `${revision.version || ""}:${revision.date || ""}:${index}`
    this.displayIndex = index
    const inactive = forceInactive || isInactiveRevision(revision)
    this.description = inactive ? "Unactivated" : revisionDescription(revision)
    this.tooltip = [
      `Transport: ${revision.version || "-"}`,
      `Title: ${revision.versionTitle || "-"}`,
      `Author: ${revision.author || "-"}`,
      `Date: ${revision.date || "-"}`,
      `Status: ${inactive ? "Unactivated" : "Active"}`
    ].join("\n")
    this.iconPath = new ThemeIcon("history")
    this.contextValue = "objectPropertyRevision"
    this.command = {
      title: "Compare with current version",
      command: "vscode.diff",
      arguments: [
        revisionUri(uri, revision),
        uri,
        `${uri.path.split("/").pop() || uri.toString()} ${revisionLabel(revision, index)}->current`
      ]
    }
    this.checkboxState = checked ? TreeItemCheckboxState.Checked : TreeItemCheckboxState.Unchecked
  }
}

class CompareSelectedHistoryItem extends TreeItem {
  constructor(
    uri: Uri,
    selectedCount: number,
    leftRevision?: Revision,
    leftIndex?: number,
    rightRevision?: Revision,
    rightIndex?: number
  ) {
    super("Compare selected", TreeItemCollapsibleState.None)
    this.description = selectedCount ? `${selectedCount} selected` : "Select 2 revisions"
    this.tooltip = "Compare two checked history entries"
    this.iconPath = new ThemeIcon("diff")
    this.contextValue = "objectPropertyHistoryCompare"
    this.command = {
      title: "Compare selected history",
      command: OBJECT_PROPERTY_COMPARE_COMMAND,
      arguments: [uri]
    }
  }
}

class HistoryPropertyItem extends TreeItem {
  constructor(
    private readonly uri: Uri,
    private readonly revisions: Revision[],
    private readonly objectInactive: boolean
  ) {
    super("History", TreeItemCollapsibleState.Collapsed)
    this.description = revisions.length ? `${revisions.length} revisions` : "No revisions"
    this.tooltip = revisions.length
      ? `Version history for the current object (${revisions.length} revisions)`
      : "No version history available for the current object"
    this.iconPath = new ThemeIcon("history")
    this.contextValue = "objectPropertyHistory"
  }

  public getChildren(): PropertyNode[] {
    if (!this.revisions.length) {
      return [new PropertyValueItem("History", "No version history available", "", "info")]
    }

    const revisions = sortRevisionsForDisplay(this.revisions)
    const items = revisions.map(
      (revision, index) =>
        new RevisionChildItem(
          this.uri,
          revision,
          index,
          ObjectPropertyProvider.get().isRevisionSelected(revision, index),
          this.objectInactive && index === 0
        )
    )
    const compareItem = ObjectPropertyProvider.get().createCompareItem(this.uri)
    return compareItem ? [compareItem, ...items] : items
  }
}

// --- Helpers ---

type PropertySnapshot = {
  description?: string
  message?: string
  items: PropertyNode[]
}

const stringifyValue = (value: unknown): string => {
  if (value === undefined || value === null || value === "") return "-"
  if (value instanceof Date) return value.toLocaleString()
  if (typeof value === "boolean") return value ? "Yes" : "No"
  return `${value}`
}

const pushIfValue = (
  target: PropertyNode[],
  key: string,
  value: unknown,
  options?: { copyValue?: string; icon?: string }
) => {
  const text = stringifyValue(value)
  if (text === "-") return
  target.push(new PropertyValueItem(key, text, options?.copyValue ?? text, options?.icon))
}

const currentMainProgram = async (object: AbapObject) => {
  if (object.type !== "PROG/I") return undefined
  return (await object.mainPrograms().catch(() => [] as MainInclude[]))[0]
}

const resolveTransportInfo = async (
  connId: string,
  object: AbapObject
): Promise<TransportInfo | undefined> => {
  try {
    return await getClient(connId).transportInfo(object.contentsPath(), "", "")
  } catch {
    return undefined
  }
}

const combinedTypeLabel = (object: AbapObject, mainProgram?: MainInclude) => {
  return getCombinedObjectTypeLabel(object.type, mainProgram)
}

const objectDescription = (object: AbapObject) => {
  const meta = (object.structure?.metaData || {}) as Record<string, unknown>
  return meta["adtcore:description"] || meta["adtcore:name"] || ""
}

const currentTransport = (lockStatus: LockStatus, transportInfo?: TransportInfo) => {
  const locked = lockStatus.status === "locked"
  const number = (locked ? lockStatus.CORRNR : transportInfo?.LOCKS?.HEADER?.TRKORR) || ""
  if (!number) return { number: "", description: "" }

  const description =
    (locked && lockStatus.CORRTEXT) ||
    transportInfo?.TRANSPORTS?.find(e => e.TRKORR === number)?.AS4TEXT ||
    transportInfo?.LOCKS?.HEADER?.AS4TEXT ||
    ""
  return { number, description }
}

const findTransportContext = (transports: any, number: string) => {
  for (const category of ["workbench", "customizing", "transportofcopies"]) {
    for (const target of transports?.[category] || []) {
      for (const status of ["modifiable", "released"]) {
        for (const request of target?.[status] || []) {
          if (request?.["tm:number"] === number) {
            return { request, tasks: request.tasks || [], isTask: false }
          }
          if ((request?.tasks || []).some((t: any) => t?.["tm:number"] === number)) {
            return { request, tasks: request.tasks || [], isTask: true }
          }
        }
      }
    }
  }
}

const transportRequestUri = (transportNumber: string) =>
  transportNumber
    ? `/sap/bc/adt/vit/wb/object_type/${encodeURIComponent("    rq")}/object_name/${encodeURIComponent(transportNumber)}`
    : ""

const isInactiveRevision = (revision: Revision) => {
  const version = revision.version?.toLowerCase() || ""
  const versionTitle = revision.versionTitle?.toLowerCase() || ""
  const uri = revision.uri?.toLowerCase() || ""
  return (
    version === "inactive" ||
    versionTitle === "inactive" ||
    versionTitle === "unactivated" ||
    uri.includes("version=inactive")
  )
}

const revisionDescription = (revision: Revision) =>
  revision.versionTitle || `${revision.author || ""} ${revision.date || ""}`.trim() || "-"

const revisionLabel = (revision: Revision, index: number) => {
  const label = revLabel(revision, `Revision ${index + 1}`)
  if (!isInactiveRevision(revision)) return label

  const genericInactive = ["inactive", "unactivated", "unactivated changes", "inactive version"]
  return genericInactive.includes(label.trim().toLowerCase())
    ? revision.version || `Revision ${index + 1}`
    : label
}

const sortRevisionsForDisplay = (revisions: Revision[]) =>
  [...revisions].sort(
    (left, right) => Number(isInactiveRevision(right)) - Number(isInactiveRevision(left))
  )

const loadRevisionHistory = async (uri: Uri, force = false): Promise<Revision[]> => {
  try {
    return (await AbapRevisionService.get(uri.authority).uriRevisions(uri, force)) || []
  } catch {
    return []
  }
}

// --- Tree data provider ---

export class ObjectPropertyProvider implements TreeDataProvider<PropertyNode>, Disposable {
  public static get() {
    return (this.instance ??= new ObjectPropertyProvider())
  }

  private static instance?: ObjectPropertyProvider

  private readonly emitter = new EventEmitter<PropertyNode | undefined | null | void>()
  private readonly disposables: Disposable[] = []
  private items: PropertyNode[] = []
  private selectedRevisionKeys: string[] = []
  private selectedRevisions = new Map<string, { revision: Revision; displayIndex: number }>()
  private view?: TreeView<PropertyNode>
  private refreshHandle?: NodeJS.Timeout
  private refreshGeneration = 0
  private pendingForceRefresh = false
  private lastUri?: string
  private historyUri?: Uri

  public readonly onDidChangeTreeData: Event<PropertyNode | undefined | null | void> =
    this.emitter.event

  private constructor() {
    this.disposables.push(
      commands.registerCommand(OBJECT_PROPERTY_COMPARE_COMMAND, async (uri?: Uri) => {
        await this.compareSelectedHistory(uri)
      }),
      window.onDidChangeActiveTextEditor(editor => {
        const uri = editor?.document.uri.toString()
        if (uri !== this.lastUri) this.scheduleRefresh(true)
      }),
      workspace.onDidSaveTextDocument(document => {
        if (document === window.activeTextEditor?.document) this.scheduleRefresh(true)
      }),
      workspace.onDidCloseTextDocument(document => {
        if (document.uri.toString() === window.activeTextEditor?.document.uri.toString()) {
          this.scheduleRefresh(true)
        }
      })
    )
  }

  public bindView(view: TreeView<PropertyNode>) {
    this.view = view
    this.disposables.push(
      view.onDidChangeVisibility(event => {
        if (event.visible) this.scheduleRefresh(true)
      })
    )
    const checkboxDisposable = (view as any).onDidChangeCheckboxState?.((event: any) => {
      void this.handleCheckboxStateChange(event)
    })
    if (checkboxDisposable) this.disposables.push(checkboxDisposable)
    this.scheduleRefresh(true)
  }

  public dispose() {
    if (this.refreshHandle) clearTimeout(this.refreshHandle)
    this.disposables.forEach(d => d.dispose())
  }

  public isRevisionSelected(revision: Revision, index: number) {
    return this.selectedRevisionKeys.includes(this.revisionSelectionKey(revision, index))
  }

  public async compareSelectedHistory(uri?: Uri) {
    const targetUri = uri || this.historyUri
    if (!targetUri || !this.historyUri || targetUri.toString() !== this.historyUri.toString()) {
      return window.showInformationMessage("Open an object history first")
    }

    const selected = this.selectedRevisionKeys
      .map(key => this.selectedRevisions.get(key))
      .filter((entry): entry is { revision: Revision; displayIndex: number } => !!entry)

    if (selected.length !== 2) {
      return window.showInformationMessage("Select exactly two history entries to compare")
    }

    const [leftEntry, rightEntry] = [...selected].sort(
      (left, right) => right.displayIndex - left.displayIndex
    )
    return commands.executeCommand(
      "vscode.diff",
      revisionUri(targetUri, leftEntry.revision),
      revisionUri(targetUri, rightEntry.revision),
      `${targetUri.path.split("/").pop() || targetUri.toString()} ${revisionLabel(leftEntry.revision, leftEntry.displayIndex)}->${revisionLabel(rightEntry.revision, rightEntry.displayIndex)}`
    )
  }

  public createCompareItem(uri: Uri): CompareSelectedHistoryItem | undefined {
    if (!this.historyUri || this.historyUri.toString() !== uri.toString()) return

    const selected = this.selectedRevisionKeys
      .map(key => this.selectedRevisions.get(key))
      .filter((entry): entry is { revision: Revision; displayIndex: number } => !!entry)
    if (selected.length !== 2) return new CompareSelectedHistoryItem(uri, selected.length)

    const [leftEntry, rightEntry] = [...selected].sort(
      (left, right) => right.displayIndex - left.displayIndex
    )
    return new CompareSelectedHistoryItem(
      uri,
      selected.length,
      leftEntry.revision,
      leftEntry.displayIndex,
      rightEntry.revision,
      rightEntry.displayIndex
    )
  }

  public getTreeItem(element: PropertyNode): TreeItem {
    return element
  }

  public getChildren(element?: PropertyNode): PropertyNode[] | Promise<PropertyNode[]> {
    if (!element) return this.items
    if (element instanceof TransportPropertyItem) return element.getChildren()
    if (element instanceof HistoryPropertyItem) return element.getChildren()
    return []
  }

  public scheduleRefresh(force = false) {
    if (!this.view?.visible) {
      // Do not schedule background refresh when the tree view is hidden.
      return
    }

    this.pendingForceRefresh ||= force
    if (this.refreshHandle) clearTimeout(this.refreshHandle)
    this.refreshHandle = setTimeout(
      () => {
        this.refreshHandle = undefined
        const shouldForce = this.pendingForceRefresh
        this.pendingForceRefresh = false
        void this.refresh(shouldForce)
      },
      force ? 0 : 250
    )
  }

  public async refresh(force = false) {
    const generation = ++this.refreshGeneration

    try {
      const snapshot = await this.buildSnapshot(force)
      if (generation !== this.refreshGeneration) return

      this.items = snapshot.items
      if (this.view) {
        this.view.description = snapshot.description
        this.view.message = snapshot.message
      }
    } catch (error) {
      if (generation !== this.refreshGeneration) return
      const message = caughtToString(error)
      log(`Object Property view refresh failed: ${message}`)
      this.items = [new PropertyValueItem("Message", message, message, "error")]
      if (this.view) {
        this.view.description = undefined
        this.view.message = "Failed to load object properties. Use refresh to retry."
      }
    }

    this.emitter.fire()
  }

  private async buildSnapshot(force = false): Promise<PropertySnapshot> {
    const uri = window.activeTextEditor?.document.uri
    const previousUri = this.lastUri
    this.lastUri = uri?.toString()
    if (previousUri && previousUri !== this.lastUri) this.clearHistorySelection()
    if (!(uri && abapUri(uri))) {
      this.clearHistorySelection()
      return {
        items: [],
        message: "Open an ABAP object from an ADT connection to inspect its properties."
      }
    }

    const root = uriRoot(uri)
    const node = await root.getNodeAsync(uri.path)
    if (!isAbapStat(node)) {
      this.clearHistorySelection()
      return {
        items: [],
        message: "The active editor is not backed by an ABAP repository object."
      }
    }

    const object = node.object
    if (force || !object.structure) await object.loadStructure(force)

    const [lockStatus, transportInfo, mainProgram, revisions] = await Promise.all([
      root.lockManager.finalStatus(uri.path),
      resolveTransportInfo(uri.authority, object),
      currentMainProgram(object),
      loadRevisionHistory(uri, force)
    ])

    const transport = currentTransport(lockStatus, transportInfo)
    const user =
      (lockStatus.status === "locked" && lockStatus.CORRUSER) || getClient(uri.authority).username

    return {
      items: this.buildItems(
        uri,
        uri.authority,
        user,
        object,
        transport,
        transportInfo,
        mainProgram,
        revisions
      ),
      description: object.name
    }
  }
  private extractFunctionType(object: AbapObject): string | undefined {
    const meta = object.structure?.metaData
    if (
      meta &&
      "fmodule:processingType" in meta &&
      typeof meta["fmodule:processingType"] === "string"
    )
      return meta["fmodule:processingType"]
  }

  private buildItems(
    uri: Uri,
    connId: string,
    user: string,
    object: AbapObject,
    transport: { number: string; description: string },
    transportInfo: TransportInfo | undefined,
    mainProgram: MainInclude | undefined,
    revisions: Revision[]
  ): PropertyNode[] {
    const items: PropertyNode[] = []
    const objectInactive = object.structure?.metaData["adtcore:version"] === "inactive"
    this.historyUri = uri
    const functionType = this.extractFunctionType(object)
    pushIfValue(items, "Name", object.name, { icon: "symbol-object" })
    pushIfValue(items, "Description", objectDescription(object), { icon: "note" })
    pushIfValue(items, "Package", transportInfo?.DEVCLASS, { icon: "package" })
    pushIfValue(items, "Type", combinedTypeLabel(object, mainProgram), { icon: "symbol-class" })
    pushIfValue(items, "Function type", functionType)
    pushIfValue(items, "Created At", object.createdAt, { icon: "history" })
    pushIfValue(items, "Created By", object.createdBy, { icon: "person" })
    pushIfValue(items, "Modified At", object.changedAt, { icon: "history" })
    pushIfValue(items, "Modified By", object.changedBy, { icon: "person" })

    if (transport.number) {
      const label = transport.description
        ? `${transport.number} (${transport.description})`
        : transport.number
      items.push(
        new TransportPropertyItem(
          label,
          connId,
          user,
          transport.number,
          transportRequestUri(transport.number)
        )
      )
    }

    items.push(new HistoryPropertyItem(uri, revisions, objectInactive))

    return items
  }

  private revisionSelectionKey(revision: Revision, index: number) {
    return revision.uri || `${revision.version || ""}:${revision.date || ""}:${index}`
  }

  private clearHistorySelection() {
    this.selectedRevisionKeys = []
    this.selectedRevisions.clear()
    this.historyUri = undefined
  }

  private async handleCheckboxStateChange(event: any) {
    let changed = false
    for (const [item, checkboxState] of event?.items || []) {
      if (!(item instanceof RevisionChildItem)) continue

      if (checkboxState === TreeItemCheckboxState.Checked) {
        if (!this.selectedRevisionKeys.includes(item.revisionKey)) {
          if (this.selectedRevisionKeys.length >= 2) {
            void window.showInformationMessage("Select only two history entries to compare")
            changed = true
            continue
          }
          this.selectedRevisionKeys = [...this.selectedRevisionKeys, item.revisionKey]
          this.selectedRevisions.set(item.revisionKey, {
            revision: item.revision,
            displayIndex: item.displayIndex
          })
          changed = true
        }
      } else if (this.selectedRevisionKeys.includes(item.revisionKey)) {
        this.selectedRevisionKeys = this.selectedRevisionKeys.filter(
          key => key !== item.revisionKey
        )
        this.selectedRevisions.delete(item.revisionKey)
        changed = true
      }
    }

    if (changed) this.emitter.fire()
  }
}
