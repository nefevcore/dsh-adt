import { getClient } from "../../adt/conections"
import { getObjectTypeConfig } from "abapobject"

/**
 * Shared utilities and types for ABAP Language Model Tools
 */

// ============================================================================
// SQL INJECTION PROTECTION
// ============================================================================

/**
 * Sanitize SAP object names to prevent SQL injection.
 * SAP object names are alphanumeric with underscores and slashes (for namespaces).
 * This function validates and sanitizes the input to ensure it's safe for SQL queries.
 *
 * @throws Error if the name contains invalid characters
 */
export function sanitizeObjectName(name: string): string {
  if (!name || typeof name !== "string") {
    throw new Error("Object name is required and must be a string")
  }

  const sanitized = name.trim().toUpperCase()

  // SAP object names: alphanumeric, underscore, forward slash (namespaces), percent (wildcards for LIKE)
  // Max length is typically 30 characters for most objects, but some can be longer
  const validPattern = /^[A-Z0-9_/%]+$/

  if (!validPattern.test(sanitized)) {
    throw new Error(
      `Invalid object name: "${name}". Only alphanumeric characters, underscores, forward slashes, and percent signs are allowed.`
    )
  }

  if (sanitized.length > 120) {
    throw new Error(`Object name too long: "${name}". Maximum length is 120 characters.`)
  }

  // Additional check: no SQL keywords or suspicious patterns
  const suspiciousPatterns = [
    /'/, // Single quotes (SQL string delimiter)
    /--/, // SQL comment
    /;/, // Statement terminator
    /\bOR\b/i, // OR keyword
    /\bAND\b/i, // AND keyword
    /\bDROP\b/i, // DROP keyword
    /\bDELETE\b/i, // DELETE keyword
    /\bUPDATE\b/i, // UPDATE keyword
    /\bINSERT\b/i // INSERT keyword
  ]

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(sanitized)) {
      throw new Error(`Object name contains suspicious pattern: "${name}"`)
    }
  }

  return sanitized
}

// ============================================================================
// DATA DICTIONARY QUERY HELPERS
// ============================================================================

/**
 * Get table type information from DD40L/DD40T
 */
export async function getTableTypeFromDD(client: any, typeName: string): Promise<string> {
  const sanitizedName = sanitizeObjectName(typeName)
  const sql = `SELECT l~TYPENAME, l~ROWTYPE, l~ROWKIND, l~DATATYPE, l~LENG, l~DECIMALS, t~DDTEXT FROM DD40L AS l INNER JOIN DD40T AS t ON l~TYPENAME = t~TYPENAME WHERE l~TYPENAME = '${sanitizedName}' AND l~AS4LOCAL = 'A' AND t~DDLANGUAGE = 'E' AND t~AS4LOCAL = 'A'`

  const result = await client.runQuery(sql, 100, true)

  if (!result || !result.values || result.values.length === 0) {
    return ""
  }

  let structure = `Table Type from DD40L/DD40T:\n`
  result.values.forEach((row: any) => {
    structure += `Type Name: ${row.TYPENAME}\n`
    if (row.DDTEXT) structure += `Description: ${row.DDTEXT}\n`
    structure += `Line Type (ROWTYPE): ${row.ROWTYPE}\n`
    structure += `Row Kind: ${row.ROWKIND}\n`
    if (row.DATATYPE) {
      structure += `Data Type: ${row.DATATYPE}`
      if (row.LENG) structure += `(${row.LENG})`
      if (row.DECIMALS) structure += ` DECIMALS ${row.DECIMALS}`
      structure += `\n`
    }
    structure += `\n This is a table type that references line type ${row.ROWTYPE}. To see the actual fields, query the line type structure.`
  })

  return structure
}

/**
 * Get table structure from DD03M
 */
export async function getTableStructureFromDD(client: any, objectName: string): Promise<string> {
  const sanitizedName = sanitizeObjectName(objectName)
  const sql = `SELECT TABNAME, FIELDNAME, ROLLNAME, DOMNAME, POSITION, KEYFLAG, MANDATORY, CHECKTABLE, INTTYPE, INTLEN, PRECFIELD, ROUTPUTLEN, DATATYPE, LENG, OUTPUTLEN, DECIMALS, DDTEXT, LOWERCASE, SIGNFLAG, LANGFLAG, VALEXI, ENTITYTAB, CONVEXIT FROM DD03M WHERE TABNAME = '${sanitizedName}' AND DDLANGUAGE = 'E' ORDER BY POSITION`

  const result = await client.runQuery(sql, 1000, true)

  if (!result || !result.values || result.values.length === 0) {
    return ""
  }

  let structure = `Fields from DD03M (Data Dictionary with Text):\n`
  result.values.forEach((row: any) => {
    const fieldName = row.FIELDNAME || ""
    const dataElement = row.ROLLNAME || ""
    const domain = row.DOMNAME || ""
    const description = row.DDTEXT || ""
    const keyFlag = row.KEYFLAG === "X" ? " [KEY]" : ""
    const mandatory = row.MANDATORY === "X" ? " [MANDATORY]" : ""
    const intType = row.INTTYPE || ""
    const intLen = row.INTLEN || ""
    const dataType = row.DATATYPE || ""
    const length = row.LENG || ""
    const decimals = row.DECIMALS || ""

    structure += `${fieldName}: ${intType || dataType}`
    if (intLen || length) structure += `(${intLen || length})`
    if (decimals) structure += ` DECIMALS(${decimals})`
    if (description) structure += ` - ${description}`
    if (dataElement) structure += ` [DE:${dataElement}]`
    if (domain) structure += ` [DOM:${domain}]`
    structure += `${keyFlag}${mandatory}\n`
  })

  return structure
}

/**
 * Get append structures from DD02L
 */
export async function getAppendStructuresFromDD(
  client: any,
  tableName: string
): Promise<Array<{ name: string; fields: number }>> {
  const sanitizedName = sanitizeObjectName(tableName)
  const sql = `SELECT TABNAME, TABCLASS FROM DD02L WHERE SQLTAB = '${sanitizedName}' AND TABCLASS = 'APPEND' AND AS4LOCAL = 'A'`

  const result = await client.runQuery(sql, 100, true)

  if (!result || !result.values || result.values.length === 0) {
    return []
  }

  const appendStructures: Array<{ name: string; fields: number }> = []

  for (const row of result.values) {
    const appendName = row.TABNAME || ""
    if (appendName) {
      // Count fields in this append structure - appendName is already from DB, but sanitize for safety
      const sanitizedAppendName = sanitizeObjectName(appendName)
      const fieldCountSql = `SELECT COUNT(*) AS CNT FROM DD03L WHERE TABNAME = '${sanitizedAppendName}' AND AS4LOCAL = 'A' AND FIELDNAME <> '.INCLUDE'`
      try {
        const fieldResult = await client.runQuery(fieldCountSql, 1, true)
        const fieldCount = fieldResult?.values?.[0]?.CNT || 0
        appendStructures.push({ name: appendName, fields: parseInt(fieldCount, 10) })
      } catch {
        appendStructures.push({ name: appendName, fields: 0 })
      }
    }
  }

  return appendStructures
}

/**
 * Get data element information from DD04L
 */
export async function getDataElementFromDD(client: any, dataElementName: string): Promise<string> {
  const sanitizedName = sanitizeObjectName(dataElementName)
  const sql = `SELECT ROLLNAME, DOMNAME, DATATYPE, LENG, DECIMALS FROM DD04L WHERE ROLLNAME = '${sanitizedName}' AND AS4LOCAL = 'A'`

  const result = await client.runQuery(sql, 100, true)

  if (!result || !result.values || result.values.length === 0) {
    return ""
  }

  let structure = `Data Element from DD04L:\n`
  result.values.forEach((row: any) => {
    structure += `Element: ${row.ROLLNAME}\n`
    structure += `Domain: ${row.DOMNAME}\n`
    structure += `Data Type: ${row.DATATYPE}(${row.LENG})`
    if (row.DECIMALS) structure += ` DECIMALS ${row.DECIMALS}`
    structure += `\n`
  })

  return structure
}

/**
 * Get domain information from DD01L
 */
export async function getDomainFromDD(client: any, domainName: string): Promise<string> {
  const sanitizedName = sanitizeObjectName(domainName)
  const headerSql = `SELECT DOMNAME, DATATYPE, LENG, DECIMALS FROM DD01L WHERE DOMNAME = '${sanitizedName}' AND AS4LOCAL = 'A'`

  const headerResult = await client.runQuery(headerSql, 10, true)

  let structure = `Domain from DD01L:\n`

  if (headerResult && headerResult.values && headerResult.values.length > 0) {
    const header = headerResult.values[0]
    structure += `Domain: ${header.DOMNAME}\n`
    structure += `Data Type: ${header.DATATYPE}(${header.LENG})`
    if (header.DECIMALS) structure += ` DECIMALS ${header.DECIMALS}`
    structure += `\n`
  }

  return structure
}

/**
 * Get complete table structure including append structures
 */
export async function getCompleteTableStructure(
  connectionId: string,
  objectName: string,
  objectUri: string
): Promise<string> {
  try {
    const client = getClient(connectionId)
    const sanitizedName = sanitizeObjectName(objectName)

    const mainTableURI = getOptimalObjectURI("TABL/TA", objectUri)
    let mainStructure = ""

    try {
      mainStructure = await client.getObjectSource(mainTableURI)
    } catch (mainError) {
      try {
        const tableFields = await getTableStructureFromDD(client, sanitizedName)
        if (tableFields) {
          mainStructure = tableFields

          const completeStructure =
            `Complete Structure for ${sanitizedName} (from DD03L — main object + ALL append structures):\n\n` +
            tableFields

          return completeStructure
        }
      } catch (fallbackError) {
        // Ignore
      }
    }

    let allAppendStructures = ""
    let appendStructuresList: Array<{ name: string; fields: number }> = []

    try {
      appendStructuresList = await getAppendStructuresFromDD(client, sanitizedName)

      if (appendStructuresList.length > 0) {
        allAppendStructures += `\n\nALL APPEND STRUCTURES (${appendStructuresList.length}):\n`
        for (const append of appendStructuresList) {
          allAppendStructures += `• ${append.name} (${append.fields} fields)\n`
        }
      }
    } catch (appendError) {
      // Append structures are optional
    }

    let completeStructure = `Complete Table Structure for ${sanitizedName} (SE11-like, includes ALL append structures):\n`
    completeStructure += ` Append Structures Found: ${appendStructuresList.length}\n\n`

    if (mainStructure) {
      completeStructure += `MAIN TABLE STRUCTURE:\n`
      completeStructure += mainStructure + "\n"
    }

    if (allAppendStructures) {
      completeStructure += allAppendStructures
    }

    return completeStructure
  } catch (error) {
    return `Could not retrieve complete table structure for ${objectName}: ${error}`
  }
}

// ============================================================================
// ENHANCEMENT TYPES AND INTERFACES
// ============================================================================

/**
 * Enhancement types and interfaces
 */
export interface EnhancementInfo {
  name: string // ENHO implementation name (e.g., 'Z_MY_ENHANCEMENT')
  spot: string // Enhancement spot fullname (e.g., '\PR:<PROG>\EX:<SPOT_NAME>\EI')
  startLine: number
  type: string // e.g., 'ENHANCEMENT'
  code?: string // Only included if needCode = true
  uri?: string // SAP enhancement URI for separate access (unique per element)
}

export interface EnhancementResult {
  hasEnhancements: boolean
  enhancements: EnhancementInfo[]
  totalEnhancements?: number
}

/**
 * 🔧 UTILITY: Get optimal URI path based on object type
 * Uses our research findings to determine whether XML metadata is sufficient
 * or if /source/main is needed for actual source code
 */
export function getOptimalObjectURI(objectType: string, baseUri: string): string {
  const config = getObjectTypeConfig(objectType)
  if (config) {
    if (config.sourceRequired) {
      const sourceUri = baseUri.endsWith("/source/main") ? baseUri : `${baseUri}/source/main`
      return sourceUri
    }
    if (config.extension?.endsWith(".xml")) {
      return baseUri
    }
  }

  // Unknown or fallback type - try /source/main
  const sourceUri = baseUri.endsWith("/source/main") ? baseUri : `${baseUri}/source/main`
  return sourceUri
}

/**
 * 🔧 UTILITY: Resolve correct URI path using findObjectPath
 */
export async function resolveCorrectURI(
  originalUri: string,
  connectionId: string
): Promise<string> {
  try {
    const client = getClient(connectionId)

    const pathSteps = await client.findObjectPath(originalUri)

    if (pathSteps && pathSteps.length > 0) {
      // Use the last path step's URI as it should be the most specific/correct
      const lastStep = pathSteps[pathSteps.length - 1]
      const resolvedUri = lastStep["adtcore:uri"] || originalUri

      if (resolvedUri !== originalUri) {
      }

      return resolvedUri
    } else {
      // logCommands.warn(`⚠️ No path steps found for URI: ${originalUri}`);
      return originalUri
    }
  } catch (pathError) {
    // logCommands.warn(`⚠️ Path resolution failed for ${originalUri}: ${pathError}`);
    return originalUri // Fallback to original
  }
}

interface CachedEnhancementResult {
  result: EnhancementResult
  timestamp: number
  needCode: boolean
}

const enhancementCache = new Map<string, CachedEnhancementResult>()
const ENHANCEMENT_CACHE_TTL = 10 * 60 * 1000 // 10 minutes
const MAX_CACHE_SIZE = 1000 // Prevent unlimited growth

setInterval(
  () => {
    const now = Date.now()
    const entriesToDelete: string[] = []

    // First pass: Remove expired entries
    for (const [key, cached] of enhancementCache.entries()) {
      if (now - cached.timestamp > ENHANCEMENT_CACHE_TTL) {
        entriesToDelete.push(key)
      }
    }

    // Delete expired entries
    for (const key of entriesToDelete) {
      enhancementCache.delete(key)
    }

    // Second pass: If still too large, remove oldest entries
    if (enhancementCache.size > MAX_CACHE_SIZE) {
      const sortedEntries = Array.from(enhancementCache.entries()).sort(
        ([, a], [, b]) => a.timestamp - b.timestamp
      )

      const toRemove = sortedEntries.slice(0, enhancementCache.size - MAX_CACHE_SIZE)
      for (const [key] of toRemove) {
        enhancementCache.delete(key)
      }
    }
  },
  5 * 60 * 1000
) // Cleanup every 5 minutes

/**
 * Get enhancement information for an ABAP object using SAP's enhancement APIs
 * Called from language model tools, search tools, and editor decorations
 */
export async function getObjectEnhancements(
  objectUriOrPath: string,
  connectionId: string,
  needCode: boolean = false
): Promise<EnhancementResult> {
  try {
    const cacheKey = `${connectionId}:${objectUriOrPath}:${needCode}`
    const cached = enhancementCache.get(cacheKey)
    const now = Date.now()

    if (cached && now - cached.timestamp < ENHANCEMENT_CACHE_TTL) {
      // Cache hit - return cached result
      return cached.result
    }

    const client = getClient(connectionId)

    // Ensure we have a proper source/main path
    let sourceMainPath = objectUriOrPath
    if (!sourceMainPath.includes("/source/main")) {
      if (sourceMainPath.endsWith("/source/main")) {
        // Already has /source/main
      } else {
        // Add /source/main to the path
        sourceMainPath = sourceMainPath.endsWith("/")
          ? `${sourceMainPath}source/main`
          : `${sourceMainPath}/source/main`
      }
    }

    const result: EnhancementResult = {
      hasEnhancements: false,
      enhancements: [],
      totalEnhancements: 0
    }

    try {
      const apiResult = await client.objectEnhancements(sourceMainPath, undefined, needCode)
      const allEnhancements: EnhancementInfo[] = apiResult.implementations.flatMap(impl =>
        impl.elements.map(el => ({
          name: impl.name, // ENHO implementation name
          spot: el.fullname, // Enhancement spot fullname (where it hooks in)
          startLine: el.position?.startLine ?? 0,
          type: "ENHANCEMENT" as const,
          code: el.source,
          uri: el.uri
        }))
      )

      if (allEnhancements.length === 0) return result

      result.hasEnhancements = true
      result.totalEnhancements = allEnhancements.length
      result.enhancements = allEnhancements

      enhancementCache.set(cacheKey, { result, timestamp: now, needCode })
      return result
    } catch (apiError) {
      return result
    }
  } catch (error) {
    // logCommands.error(`❌ Error getting enhancements: ${error}`);
    return {
      hasEnhancements: false,
      enhancements: [],
      totalEnhancements: 0
    }
  }
}
