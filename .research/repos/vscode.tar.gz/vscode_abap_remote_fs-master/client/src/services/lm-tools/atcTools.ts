/**
 * ABAP ATC (ABAP Test Cockpit) Tools
 * Run ATC analysis and access ATC decorations
 */

import * as vscode from "vscode"
import { registerToolWithRegistry } from "./toolRegistry"
import { funWindow as window } from "../funMessenger"
import { getSearchService } from "../abapSearchService"
import { logTelemetry } from "../telemetry"
import { getClient, getOrCreateRoot, abapUri } from "../../adt/conections"
import { atcProvider } from "../../views/abaptestcockpit"
import { getATCDecorations } from "../../views/abaptestcockpit/decorations"
import { assertToolInvocationAuthorized } from "./toolGuard"
import { listAtcVariants, AtcVariant } from "../../adt/atcVariants"

// ============================================================================
// INTERFACES
// ============================================================================

export interface IRunATCAnalysisParameters {
  action?: "run_analysis" | "get_documentation" | "get_atc_variants"
  objectName?: string
  objectType?: string
  objectUri?: string
  connectionId?: string
  useActiveFile?: boolean
  scope?: "object" | "package" | "transport"
  // For run_analysis action
  variantName?: string
  // For get_documentation action
  docUri?: string
  // For get_atc_variants action
  query?: string
  maxItems?: number
}

export interface IGetATCDecorationsParameters {
  fileUri?: string
}

// ============================================================================
// TOOL CLASSES
// ============================================================================

/**
 * 🔍 RUN ATC ANALYSIS TOOL - Wrapper for existing ATC logic with AI integration
 */
export class RunATCAnalysisTool implements vscode.LanguageModelTool<IRunATCAnalysisParameters> {
  async prepareInvocation(
    options: vscode.LanguageModelToolInvocationPrepareOptions<IRunATCAnalysisParameters>,
    _token: vscode.CancellationToken
  ) {
    const {
      action = "run_analysis",
      objectName,
      objectType,
      objectUri,
      connectionId,
      useActiveFile,
      docUri,
      variantName,
      query = "*"
    } = options.input

    // get_documentation only needs docUri + connectionId
    if (action === "get_documentation") {
      if (!docUri) {
        throw new Error("get_documentation requires docUri (from a previous run_analysis result)")
      }
      if (!connectionId) {
        throw new Error("get_documentation requires connectionId")
      }
      return {
        invocationMessage: `Fetching ATC finding documentation...`,
        confirmationMessages: {
          title: "Get ATC Documentation",
          message: new vscode.MarkdownString(
            `Fetch documentation for ATC finding from ${connectionId}`
          )
        }
      }
    }

    // get_atc_variants only needs connectionId
    if (action === "get_atc_variants") {
      if (!connectionId) {
        throw new Error("get_atc_variants requires connectionId")
      }
      return {
        invocationMessage: `Listing ATC check variants...`,
        confirmationMessages: {
          title: "List ATC Check Variants",
          message: new vscode.MarkdownString(
            `List ATC check variants on ${connectionId} matching \`${query}\``
          )
        }
      }
    }

    // Validate: must have objectUri, objectName+connectionId, or useActiveFile
    if (objectUri) {
      if (!objectUri.startsWith("adt://")) {
        throw new Error("objectUri must be a valid ADT URI (adt://system/path)")
      }
    } else if (objectName) {
      if (!connectionId) {
        throw new Error("connectionId is required when specifying objectName")
      }
    } else if (!useActiveFile) {
      throw new Error(
        "No target specified. Provide objectName+connectionId, objectUri, or set useActiveFile to true."
      )
    }

    let target = "active file"
    if (objectName) {
      target = objectType ? `${objectType} ${objectName}` : objectName
    } else if (objectUri) {
      target = `object at ${objectUri}`
    }

    const confirmationMessages = {
      title: "Run ATC Analysis",
      message: new vscode.MarkdownString(
        `Run ABAP Test Cockpit analysis on: ${target}` +
          (connectionId ? ` (connection: ${connectionId})` : "") +
          (variantName ? ` using variant \`${variantName}\`` : "") +
          "\n\nThis will update the ATC panel with visual highlights and return structured results for AI analysis."
      )
    }

    return {
      invocationMessage: `Running ATC analysis on ${target}...`,
      confirmationMessages
    }
  }

  async invoke(
    options: vscode.LanguageModelToolInvocationOptions<IRunATCAnalysisParameters>,
    _token: vscode.CancellationToken
  ): Promise<vscode.LanguageModelToolResult> {
    assertToolInvocationAuthorized(options)
    const { action = "run_analysis", variantName } = options.input
    let { objectName, objectType, objectUri, connectionId, useActiveFile = true } = options.input
    logTelemetry("tool_run_atc_analysis_called", { connectionId })

    if (connectionId) {
      connectionId = connectionId.toLowerCase()
    }

    // Handle get_documentation action
    if (action === "get_documentation") {
      return this.getDocumentation(options.input)
    }

    // Handle get_atc_variants action
    if (action === "get_atc_variants") {
      return this.getVariants(options.input)
    }

    try {
      let targetUri: vscode.Uri
      let actualConnectionId = connectionId

      if (objectUri) {
        if (!objectUri.startsWith("adt://")) {
          throw new Error("Object URI must be a valid ADT URI (adt://system/path)")
        }
        targetUri = vscode.Uri.parse(objectUri)
        actualConnectionId = actualConnectionId || targetUri.authority
      } else if (objectName) {
        if (!actualConnectionId) {
          throw new Error("connectionId is required when specifying objectName")
        }

        const searcher = getSearchService(actualConnectionId)
        const searchResults = await searcher.searchObjects(
          objectName,
          objectType ? [objectType as any] : undefined,
          1
        )

        if (!searchResults || searchResults.length === 0) {
          throw new Error(
            `Could not find ABAP object: ${objectName}${objectType ? ` (type: ${objectType})` : ""}`
          )
        }

        const objectInfo = searchResults[0]
        if (!objectInfo.uri) {
          throw new Error(`Could not get URI for ABAP object: ${objectName}`)
        }

        const root = await getOrCreateRoot(actualConnectionId)
        const { path } = (await root.findByAdtUri(objectInfo.uri, true)) || {}

        if (!path) {
          throw new Error(`Could not resolve workspace path for object ${objectName}`)
        }

        const workspaceUri = `adt://${actualConnectionId}${path}`
        targetUri = vscode.Uri.parse(workspaceUri)
      } else if (useActiveFile) {
        const activeEditor = window.activeTextEditor
        if (!activeEditor) {
          throw new Error(
            "No active editor and no object specified. Please open an ABAP file or provide objectName/objectUri."
          )
        }

        if (!abapUri(activeEditor.document.uri)) {
          throw new Error(
            "Active file is not an ABAP document. Please open an ABAP file or provide objectName/objectUri."
          )
        }

        targetUri = activeEditor.document.uri
        actualConnectionId = actualConnectionId || targetUri.authority
      } else {
        throw new Error(
          "No target specified for ATC analysis. Provide objectName, objectUri, or set useActiveFile to true."
        )
      }

      // atcProvider is imported statically at top

      const existingEditor = window.visibleTextEditors.find(
        editor => editor.document.uri.toString() === targetUri.toString()
      )

      if (existingEditor) {
        try {
          const fileSystemContent = await vscode.workspace.fs.readFile(existingEditor.document.uri)
          const fileSystemText = Buffer.from(fileSystemContent).toString("utf8")
          const editorText = existingEditor.document.getText()
          const hasContentDifference = fileSystemText !== editorText

          if (hasContentDifference) {
            const objectName = targetUri.path.split("/").pop() || "object"
            const errorMessage =
              ` Cannot run ATC analysis on ${objectName}\n\n` +
              `The file has unsaved changes (including potential Copilot modifications). ` +
              `ATC analysis would run on the old server version, not your current changes, making results inaccurate.\n\n` +
              `Please ask user to:\n` +
              `1. save the file (Ctrl+S or click "Keep" if you have Copilot changes)\n` +
              `2. Activate the object\n` +
              `3. Run ATC analysis again for accurate results\n\n` +
              `This ensures ATC analyzes your actual current code, not the old version.`

            return new vscode.LanguageModelToolResult([
              new vscode.LanguageModelTextPart(errorMessage)
            ])
          }
        } catch {
          // Ignore fs errors
        }
      }

      const usedVariant = await window.withProgress(
        { location: vscode.ProgressLocation.Notification, title: "Running ABAP Test Cockpit" },
        async () => {
          try {
            if (!existingEditor) {
              const document = await vscode.workspace.openTextDocument(targetUri)
              await window.showTextDocument(document, { preserveFocus: true })
            }
          } catch {
            // Continue with ATC even if file opening fails
          }

          return atcProvider.runInspector(targetUri, undefined, variantName)
        }
      )

      const resolvedVariantName = usedVariant || "unknown"
      const findings = atcProvider.findings()

      const structuredFindings = findings.map(finding => ({
        object: {
          name: finding.parent.object.name,
          type: finding.parent.object.type
        },
        finding: {
          messageTitle: finding.finding.messageTitle,
          checkTitle: finding.finding.checkTitle,
          checkId: finding.finding.checkId,
          priority: finding.finding.priority,
          priorityText:
            finding.finding.priority === 1
              ? "Error"
              : finding.finding.priority === 2
                ? "Warning"
                : "Info",
          location: {
            uri: finding.uri,
            line: finding.start.line + 1,
            character: finding.start.character + 1
          },
          hasExemption: !!finding.finding.exemptionApproval,
          exemptionStatus: finding.finding.exemptionApproval || null,
          docUri: finding.finding.link?.href || null
        }
      }))

      const totalFindings = structuredFindings.length
      const errors = structuredFindings.filter(f => f.finding.priority === 1).length
      const warnings = structuredFindings.filter(f => f.finding.priority === 2).length
      const infos = structuredFindings.filter(f => f.finding.priority === 3).length
      const exempted = structuredFindings.filter(f => f.finding.hasExemption).length

      const findingsByObject = structuredFindings.reduce(
        (acc, finding) => {
          const key = `${finding.object.type} ${finding.object.name}`
          if (!acc[key]) acc[key] = []
          acc[key].push(finding)
          return acc
        },
        {} as Record<string, any[]>
      )

      const resultText =
        `ATC Analysis Complete\n` +
        `Target: ${targetUri.toString()}\n` +
        `System: ${actualConnectionId}\n` +
        `Check Variant: ${resolvedVariantName}\n` +
        `Findings: ${totalFindings} (${errors}E ${warnings}W ${infos}I, ${exempted} exempted)\n` +
        `Objects Analyzed: ${Object.keys(findingsByObject).length}\n\n` +
        `Per-object:\n` +
        Object.entries(findingsByObject)
          .map(
            ([objectKey, findings]) =>
              `• ${objectKey}: ${findings.length} (` +
              `${findings.filter(f => f.finding.priority === 1).length}E, ` +
              `${findings.filter(f => f.finding.priority === 2).length}W, ` +
              `${findings.filter(f => f.finding.priority === 3).length}I)`
          )
          .join("\n") +
        `\n\nResults also displayed in ATC Finds panel.`

      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(resultText),
        new vscode.LanguageModelTextPart(
          `\nStructured Findings Data:\n${JSON.stringify(
            {
              summary: {
                totalFindings,
                errors,
                warnings,
                infos,
                exempted,
                checkVariant: resolvedVariantName,
                targetUri: targetUri.toString(),
                connectionId: actualConnectionId
              },
              findings: structuredFindings
            },
            null,
            2
          )}`
        )
      ])
    } catch (error) {
      throw new Error(`Failed to run ATC analysis: ${String(error)}`)
    }
  }

  private async getDocumentation(
    input: IRunATCAnalysisParameters
  ): Promise<vscode.LanguageModelToolResult> {
    const { docUri, connectionId } = input

    if (!docUri) {
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(
          "Missing parameter: get_documentation requires `docUri` — the documentation URL from a finding. " +
            "Use the exact docUri value from the findings returned by a previous run_analysis call."
        )
      ])
    }

    if (!connectionId) {
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(
          "Missing parameter: get_documentation requires `connectionId` to fetch documentation from the correct SAP system."
        )
      ])
    }

    const client = getClient(connectionId)
    const doc = await client.atcDocumentation(docUri)

    // Strip HTML tags to get plain text for the AI
    const plainText = doc.body
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/p>/gi, "\n\n")
      .replace(/<\/div>/gi, "\n")
      .replace(/<\/li>/gi, "\n")
      .replace(/<li[^>]*>/gi, "• ")
      .replace(/<\/h[1-6]>/gi, "\n\n")
      .replace(/<h[1-6][^>]*>/gi, "\n## ")
      .replace(/<[^>]+>/g, "")
      .replace(/&nbsp;/g, " ")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&amp;/g, "&")
      .replace(/&quot;/g, '"')
      .replace(/\n{3,}/g, "\n\n")
      .trim()

    const resultText =
      `ATC Finding Documentation\n` +
      `Doc URI: ${docUri}\n` +
      `System: ${connectionId}\n\n` +
      `Documentation:\n\n${plainText}`

    return new vscode.LanguageModelToolResult([new vscode.LanguageModelTextPart(resultText)])
  }

  private async getVariants(
    input: IRunATCAnalysisParameters
  ): Promise<vscode.LanguageModelToolResult> {
    const { connectionId, query = "*", maxItems = 100 } = input

    if (!connectionId) {
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(
          "Missing parameter: get_atc_variants requires `connectionId` to know which SAP system to query."
        )
      ])
    }

    let variants: AtcVariant[]
    try {
      const client = getClient(connectionId.toLowerCase())
      variants = await listAtcVariants(client, query, maxItems)
    } catch (error) {
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(
          `Could not list ATC check variants on ${connectionId}: ${String(error)}\n\n` +
            `This system may not support variant listing (older SAP releases). ` +
            `You can still call run_analysis with a variantName you already know, ` +
            `or omit variantName to use the connection's configured/default variant.`
        )
      ])
    }

    const capped = variants.length >= maxItems

    const resultText =
      `ATC Check Variants\n` +
      `System: ${connectionId}\n` +
      `Query: ${query}\n` +
      `Found: ${variants.length}${capped ? " (capped)" : ""}\n\n` +
      (variants.length
        ? variants.map(v => `• ${v.name}${v.description ? ` — ${v.description}` : ""}`).join("\n")
        : "No matching variants found.") +
      (capped
        ? `\n\nResults capped at maxItems=${maxItems}. Narrow the \`query\` parameter (wildcard, e.g. 'Z*') to see more without missing variants.`
        : "")

    return new vscode.LanguageModelToolResult([new vscode.LanguageModelTextPart(resultText)])
  }
}

/**
 * 🎨 GET ATC DECORATIONS TOOL - Access current visual decorations in editor
 */
export class GetATCDecorationsTool implements vscode.LanguageModelTool<IGetATCDecorationsParameters> {
  async prepareInvocation(
    options: vscode.LanguageModelToolInvocationPrepareOptions<IGetATCDecorationsParameters>,
    _token: vscode.CancellationToken
  ) {
    const { fileUri } = options.input

    const target = fileUri ? `file: ${fileUri}` : "all files with ATC decorations"

    const confirmationMessages = {
      title: "Get ATC Decorations",
      message: new vscode.MarkdownString(
        `Access current ATC visual decorations for: ${target}\n\n` +
          "This will return the current state of error/warning/info highlights visible in the editor."
      )
    }

    return {
      invocationMessage: `Getting ATC decorations for ${target}...`,
      confirmationMessages
    }
  }

  async invoke(
    options: vscode.LanguageModelToolInvocationOptions<IGetATCDecorationsParameters>,
    _token: vscode.CancellationToken
  ): Promise<vscode.LanguageModelToolResult> {
    assertToolInvocationAuthorized(options)
    const { fileUri } = options.input
    const connectionId = fileUri ? vscode.Uri.parse(fileUri).authority : undefined
    logTelemetry("tool_get_atc_decorations_called", { connectionId })

    try {
      const decorationData = getATCDecorations(fileUri)

      let resultText = ""
      let findingsCount = 0

      if (fileUri) {
        const fileData = decorationData as { fileUri: string; decorations: any[] }
        findingsCount = fileData.decorations.length

        resultText =
          `ATC Decorations for File\n` +
          `File: ${fileUri}\n` +
          `Total Decorations: ${findingsCount}\n\n`

        if (findingsCount > 0) {
          const errors = fileData.decorations.filter(d => d.priority === 1).length
          const warnings = fileData.decorations.filter(d => d.priority === 2).length
          const infos = fileData.decorations.filter(d => d.priority === 3).length
          const exempted = fileData.decorations.filter(d => d.hasExemption).length

          resultText +=
            `${errors}E (red) | ${warnings}W (yellow) | ${infos}I (blue) | ${exempted} exempted (green)\n\n` +
            `Decorations:\n` +
            fileData.decorations
              .map(d => `• Line ${d.line}: ${d.message} (${d.priorityText}) [${d.decorationType}]`)
              .join("\n")
        } else {
          resultText += `No decorations visible — clean code or no ATC analysis run yet.`
        }
      } else {
        const allData = decorationData as {
          totalFiles: number
          totalFindings: number
          decorations: Record<string, any[]>
        }
        findingsCount = allData.totalFindings

        resultText =
          `All ATC Decorations\n` +
          `Files with Decorations: ${allData.totalFiles}\n` +
          `Total Decorations: ${allData.totalFindings}\n\n`

        if (allData.totalFiles > 0) {
          resultText +=
            `Files Overview:\n` +
            Object.entries(allData.decorations)
              .map(([uri, decorations]) => {
                const errors = decorations.filter(d => d.priority === 1).length
                const warnings = decorations.filter(d => d.priority === 2).length
                const infos = decorations.filter(d => d.priority === 3).length
                return `• ${uri}: ${decorations.length} (${errors}E ${warnings}W ${infos}I)`
              })
              .join("\n")
        } else {
          resultText += `No decorations in any files — all code clean or no ATC analysis run yet.`
        }
      }

      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(resultText),
        new vscode.LanguageModelTextPart(
          `\nStructured Decoration Data:\n${JSON.stringify(decorationData, null, 2)}`
        )
      ])
    } catch (error) {
      throw new Error(`Failed to get ATC decorations: ${String(error)}`)
    }
  }
}

// ============================================================================
// REGISTRATION
// ============================================================================

export function registerAtcTools(context: vscode.ExtensionContext): void {
  context.subscriptions.push(registerToolWithRegistry("run_atc_analysis", new RunATCAnalysisTool()))
  context.subscriptions.push(
    registerToolWithRegistry("get_atc_decorations", new GetATCDecorationsTool())
  )
}
