/**
 * MCP Server for ABAP FS - Exposes tools via Model Context Protocol
 *
 * This dynamically wraps all VS Code Language Model tools registered by ABAP FS
 * and exposes them as MCP tools for external AI clients (Cursor, Claude Desktop, etc.)
 *
 * Usage in other AI tools config:
 * {
 *   "mcpServers": {
 *     "abap-fs": {
 *       "url": "http://localhost:<port>/mcp"
 *     }
 *   }
 * }
 */

import * as vscode from "vscode"
import * as http from "http"
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js"
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js"
import { isInitializeRequest } from "@modelcontextprotocol/sdk/types.js"
import { randomUUID } from "crypto"
import { z } from "zod"
import { log } from "../lib"
import { toolRegistry } from "./lm-tools/toolRegistry"
import { createMcpAuthorizedOptions } from "./lm-tools/toolGuard"
import { funWindow as window } from "./funMessenger"
import { executeReplace } from "./lm-tools/mcpReplaceStringTool"
import { getDiagnosticsForUri } from "./lm-tools/mcpGetDiagnosticsTool"

// ============================================================================
// TYPES
// ============================================================================

interface McpServerState {
  httpServer: http.Server | null
  isRunning: boolean
  port: number
}

// Map to store transports by session ID
const transports: { [sessionId: string]: StreamableHTTPServerTransport } = {}

// ============================================================================
// STATE & SETTINGS
// ============================================================================

const state: McpServerState = {
  httpServer: null,
  isRunning: false,
  port: 4847
}

/**
 * Get MCP server settings from VS Code configuration
 */
function getMcpSettings(): { autoStart: boolean; port: number; apiKey: string } {
  const config = vscode.workspace.getConfiguration("abapfs.mcpServer")
  return {
    autoStart: config.get<boolean>("autoStart", false),
    port: config.get<number>("port", 4847),
    apiKey: config.get<string>("apiKey", "")
  }
}

/**
 * Validate the API key from the request Authorization header.
 * Returns true if authentication passes, false otherwise.
 */
let apiKeyWarningLogged = false

export function validateApiKey(req: http.IncomingMessage): boolean {
  const settings = getMcpSettings()

  // If no API key is configured, allow access (for backwards compatibility)
  // but log a warning once per session
  if (!settings.apiKey) {
    if (!apiKeyWarningLogged) {
      log(
        "No API key configured for the MCP server. Consider configuring a random key and passing it in your MCP client. Allowing anyway.."
      )
      apiKeyWarningLogged = true
    }
    return true
  }

  const authHeader = req.headers["authorization"]
  if (!authHeader) {
    return false
  }

  // Support both "Bearer <token>" and plain "<token>" formats
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : authHeader

  // Constant-time comparison to prevent timing attacks
  if (token.length !== settings.apiKey.length) {
    return false
  }

  let result = 0
  for (let i = 0; i < token.length; i++) {
    result |= token.charCodeAt(i) ^ settings.apiKey.charCodeAt(i)
  }

  return result === 0
}

// ============================================================================
// JSON SCHEMA TO ZOD CONVERTER
// ============================================================================

/**
 * Convert a JSON Schema property to a Zod schema.
 * This is a simplified converter that handles the most common cases.
 */
export function jsonSchemaPropertyToZod(
  propSchema: Record<string, unknown>,
  isRequired: boolean
): z.ZodTypeAny {
  const type = propSchema.type as string | undefined
  const description = propSchema.description as string | undefined

  let zodType: z.ZodTypeAny

  switch (type) {
    case "string":
      if (propSchema.enum && Array.isArray(propSchema.enum)) {
        // Handle enum strings
        const enumValues = propSchema.enum as [string, ...string[]]
        zodType = z.enum(enumValues)
      } else {
        zodType = z.string()
      }
      break
    case "number":
    case "integer":
      zodType = z.number()
      break
    case "boolean":
      zodType = z.boolean()
      break
    case "array":
      const itemsSchema = propSchema.items as Record<string, unknown> | undefined
      if (itemsSchema) {
        zodType = z.array(jsonSchemaPropertyToZod(itemsSchema, true))
      } else {
        zodType = z.array(z.unknown())
      }
      break
    case "object":
      const objProperties = propSchema.properties as
        | Record<string, Record<string, unknown>>
        | undefined
      const objRequired = (propSchema.required as string[]) || []
      if (objProperties) {
        const shape: Record<string, z.ZodTypeAny> = {}
        for (const [key, value] of Object.entries(objProperties)) {
          shape[key] = jsonSchemaPropertyToZod(value, objRequired.includes(key))
        }
        zodType = z.object(shape)
      } else {
        zodType = z.record(z.string(), z.unknown())
      }
      break
    default:
      // Unknown or missing type - accept anything
      zodType = z.unknown()
  }

  // Add description if present
  if (description) {
    zodType = zodType.describe(description)
  }

  // Make optional if not required
  if (!isRequired) {
    zodType = zodType.optional()
  }

  return zodType
}

/**
 * Convert a full JSON Schema (with properties) to a Zod object schema.
 */
export function jsonSchemaToZod(
  jsonSchema: Record<string, unknown> | undefined
): Record<string, z.ZodTypeAny> {
  if (!jsonSchema) {
    return {}
  }

  const properties = jsonSchema.properties as Record<string, Record<string, unknown>> | undefined
  const required = (jsonSchema.required as string[]) || []

  if (!properties) {
    return {}
  }

  const zodShape: Record<string, z.ZodTypeAny> = {}

  for (const [propName, propSchema] of Object.entries(properties)) {
    zodShape[propName] = jsonSchemaPropertyToZod(propSchema, required.includes(propName))
  }

  return zodShape
}

// ============================================================================
// DYNAMIC TOOL WRAPPER
// ============================================================================

// Tag used to identify ABAP FS tools
const ABAP_FS_TAG = "abap-fs"

/**
 * Create an MCP server that dynamically wraps all VS Code LM tools
 */
function createMcpServer(): McpServer {
  const server = new McpServer({
    name: "abap-fs",
    version: "1.0.0"
  })

  // Get all registered LM tools and filter to only ABAP FS tools
  const allTools = vscode.lm.tools
  const abapTools = allTools.filter(tool => tool.tags.includes(ABAP_FS_TAG))

  for (const tool of abapTools) {
    const toolName = tool.name
    const toolDescription = tool.description || `ABAP FS tool: ${toolName}`
    const inputSchema = tool.inputSchema as Record<string, unknown> | undefined

    // Convert JSON Schema to Zod schema
    const zodSchema = jsonSchemaToZod(inputSchema)

    // Register each LM tool as an MCP tool
    server.registerTool(
      toolName,
      {
        title: toolName.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
        description: toolDescription,
        inputSchema: zodSchema
      },
      async (args: Record<string, unknown>) => {
        try {
          const tokenSource = new vscode.CancellationTokenSource()

          // Look up the tool instance from our shared registry so we can
          // call invoke() directly, bypassing vscode.lm.invokeTool() and
          // its prepareInvocation confirmation dialog pipeline.
          const registeredTool = toolRegistry.get(toolName)
          let result: vscode.LanguageModelToolResult

          if (registeredTool) {
            const authorizedOptions = createMcpAuthorizedOptions(args)
            const invokeResult = await registeredTool.invoke(
              authorizedOptions as vscode.LanguageModelToolInvocationOptions<any>,
              tokenSource.token
            )
            if (!invokeResult) {
              throw new Error(`Tool ${toolName} returned no result`)
            }
            result = invokeResult
          } else {
            result = await vscode.lm.invokeTool(
              toolName,
              { input: args, toolInvocationToken: undefined },
              tokenSource.token
            )
          }

          const textParts: string[] = []

          for await (const part of result.content) {
            if (part instanceof vscode.LanguageModelTextPart) {
              textParts.push(part.value)
            } else if (typeof part === "object" && part !== null && "value" in part) {
              const partWithValue = part as { value: unknown }
              if (typeof partWithValue.value === "string") {
                textParts.push(partWithValue.value)
              } else {
                textParts.push(JSON.stringify(partWithValue.value))
              }
            } else {
              textParts.push(JSON.stringify(part))
            }
          }

          const resultText = textParts.join("\n")

          return {
            content: [
              {
                type: "text" as const,
                text: resultText
              }
            ]
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error)

          return {
            content: [
              {
                type: "text" as const,
                text: `❌ Error invoking ${toolName}: ${errorMessage}`
              }
            ],
            isError: true
          }
        }
      }
    )
  }

  // ============================================================================
  // MCP-ONLY TOOLS (not available as VS Code LM tools)
  // ============================================================================

  // Replace String in ABAP Object - enables MCP clients to edit ABAP source code
  server.registerTool(
    "replace_string_in_abap_object",
    {
      title: "Replace String In ABAP Object",
      description:
        "Edit ABAP source code by replacing a specific text string with new text. " +
        "This tool performs a find-and-replace operation on an ABAP source file identified by its workspace URI. " +
        "The oldString must match EXACTLY ONE occurrence in the file - include 3-5 lines of surrounding context to ensure uniqueness. " +
        "The file is automatically locked, saved to SAP, and unlocked.\n\n" +
        "Prerequisites: First call get_abap_object_workspace_uri to get the fileUri. " +
        "Then call get_abap_object_lines or search_abap_object_lines to read current content before editing.\n\n" +
        "IMPORTANT: oldString is mandatory whenever the file has any content. An empty oldString is accepted ONLY when the file is currently completely blank (e.g. a freshly created ABAP object with no source yet) - in that case the entire newString becomes the file content.\n\n" +
        "After editing, call get_abap_diagnostics with the same fileUri to verify the code has no syntax errors.",
      inputSchema: {
        fileUri: z
          .string()
          .describe(
            "The full workspace URI of the ABAP source file." +
              "Get this using the get_abap_object_workspace_uri tool."
          ),
        oldString: z
          .string()
          .describe(
            "The exact literal text to find and replace. Must match exactly one occurrence in the file. " +
              "Include at least 3-5 lines of surrounding context to ensure uniqueness. " +
              "Must match whitespace and indentation precisely. " +
              "May be an empty string ONLY if the target file is currently completely blank; otherwise it is mandatory."
          ),
        newString: z
          .string()
          .describe("The replacement text. Ensure the resulting code is syntactically valid ABAP.")
      }
    },
    async (args: Record<string, unknown>) => {
      try {
        const fileUri = args.fileUri as string
        const oldString = args.oldString as string
        const newString = args.newString as string

        if (!fileUri) {
          throw new Error("fileUri is required")
        }
        if (newString === undefined || newString === null) {
          throw new Error("newString is required (use empty string to delete text)")
        }
        // Note: empty oldString is allowed only when the file is blank.
        // That check happens inside executeReplace/findAndReplace once the
        // current file content is known.

        await executeReplace(fileUri, oldString, newString)

        const oldLineCount = oldString.split("\n").length
        const newLineCount = newString.split("\n").length

        return {
          content: [
            {
              type: "text" as const,
              text:
                `✅ Successfully replaced ${oldLineCount} line(s) with ${newLineCount} line(s) in ${fileUri}\n\n` +
                `The file has been saved and synced to SAP.`
            }
          ]
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error)
        return {
          content: [
            {
              type: "text" as const,
              text: `❌ Error: ${errorMessage}`
            }
          ],
          isError: true
        }
      }
    }
  )

  // Get Diagnostics - returns syntax errors/warnings for a given ABAP file
  server.registerTool(
    "get_abap_diagnostics",
    {
      title: "Get ABAP Diagnostics",
      description:
        "Get syntax errors, warnings, and other diagnostics for an ABAP source file. " +
        "Returns all problems detected by the ABAP language server (syntax check results). " +
        "Use this after editing code with replace_string_in_abap_object to verify there are no syntax errors. " +
        "Always call this after making code changes.\n\n" +
        "Prerequisite: Use get_abap_object_workspace_uri to get the fileUri.",
      inputSchema: {
        fileUri: z
          .string()
          .describe(
            "The full workspace URI of the ABAP source file. " +
              "Get this using the get_abap_object_workspace_uri tool."
          )
      }
    },
    async (args: Record<string, unknown>) => {
      try {
        const fileUri = args.fileUri as string
        if (!fileUri) {
          throw new Error("fileUri is required")
        }

        const result = await getDiagnosticsForUri(fileUri)

        return {
          content: [{ type: "text" as const, text: result }]
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error)
        return {
          content: [{ type: "text" as const, text: `❌ Error: ${errorMessage}` }],
          isError: true
        }
      }
    }
  )

  return server
}

// ============================================================================
// HTTP SERVER WITH STREAMABLE HTTP TRANSPORT (Per-Session)
// ============================================================================

/**
 * Parse JSON body from incoming request
 */
async function parseJsonBody(req: http.IncomingMessage): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    req.on("data", (chunk: Buffer) => chunks.push(chunk))
    req.on("end", () => {
      try {
        const body = Buffer.concat(chunks).toString("utf8")
        resolve(body ? JSON.parse(body) : {})
      } catch (e) {
        reject(e)
      }
    })
    req.on("error", reject)
  })
}

async function startHttpServer(): Promise<void> {
  if (state.isRunning) {
    return
  }

  // Get configured port from settings
  const settings = getMcpSettings()
  state.port = settings.port

  state.httpServer = http.createServer(async (req, res) => {
    if (req.method === "OPTIONS") {
      res.writeHead(405)
      res.end()
      return
    }

    const url = new URL(req.url || "/", `http://localhost:${state.port}`)

    // Health check endpoint (no auth required)
    if (url.pathname === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" })
      res.end(JSON.stringify({ status: "ok", server: "abap-fs-mcp" }))
      return
    }

    // Authentication check for all other endpoints
    if (!validateApiKey(req)) {
      res.writeHead(401, { "Content-Type": "application/json" })
      res.end(
        JSON.stringify({
          jsonrpc: "2.0",
          error: {
            code: -32001,
            message:
              "Unauthorized: Invalid or missing API key. Set the API key in the Authorization header (Bearer <token>)."
          },
          id: null
        })
      )
      return
    }

    // MCP endpoint - handles all MCP protocol messages
    if (url.pathname === "/mcp") {
      const sessionId = req.headers["mcp-session-id"] as string | undefined

      // Handle POST requests (JSON-RPC messages)
      if (req.method === "POST") {
        try {
          const body = await parseJsonBody(req)

          let transport: StreamableHTTPServerTransport

          if (sessionId && transports[sessionId]) {
            // Reuse existing transport for this session
            transport = transports[sessionId]
          } else if (!sessionId && isInitializeRequest(body)) {
            // New initialization request - create new transport and server
            transport = new StreamableHTTPServerTransport({
              sessionIdGenerator: () => randomUUID(),
              onsessioninitialized: (newSessionId: string) => {
                transports[newSessionId] = transport
              }
            })

            // Clean up on close
            transport.onclose = () => {
              const sid = transport.sessionId
              if (sid && transports[sid]) {
                delete transports[sid]
              }
            }

            // Create a new MCP server instance and connect it to this transport
            const server = createMcpServer()
            await server.connect(transport)

            // Handle the initialization request
            await transport.handleRequest(req, res, body)
            return
          } else {
            // Invalid request - no session ID and not an initialization request
            res.writeHead(400, { "Content-Type": "application/json" })
            res.end(
              JSON.stringify({
                jsonrpc: "2.0",
                error: {
                  code: -32000,
                  message: "Bad Request: No valid session ID provided"
                },
                id: null
              })
            )
            return
          }

          // Handle the request with existing transport
          await transport.handleRequest(req, res, body)
        } catch {
          if (!res.headersSent) {
            res.writeHead(500, { "Content-Type": "application/json" })
            res.end(
              JSON.stringify({
                jsonrpc: "2.0",
                error: { code: -32603, message: "Internal server error" },
                id: null
              })
            )
          }
        }
        return
      }

      // Handle GET requests for SSE streams
      if (req.method === "GET") {
        if (!sessionId || !transports[sessionId]) {
          res.writeHead(400, { "Content-Type": "application/json" })
          res.end(JSON.stringify({ error: "Invalid or missing session ID" }))
          return
        }
        const transport = transports[sessionId]
        await transport.handleRequest(req, res)
        return
      }

      // Handle DELETE requests for session termination
      if (req.method === "DELETE") {
        if (!sessionId || !transports[sessionId]) {
          res.writeHead(400, { "Content-Type": "application/json" })
          res.end(JSON.stringify({ error: "Invalid or missing session ID" }))
          return
        }
        const transport = transports[sessionId]
        await transport.handleRequest(req, res)
        return
      }
    }

    // Root endpoint with info
    if (url.pathname === "/") {
      res.writeHead(200, { "Content-Type": "application/json" })
      res.end(
        JSON.stringify({
          name: "ABAP FS MCP Server",
          version: "1.0.0",
          description: "MCP server exposing ABAP FS tools for external AI clients",
          endpoints: {
            mcp: "/mcp - Streamable HTTP endpoint for MCP connection",
            health: "/health - Health check endpoint"
          },
          usage: {
            cursor: `Add to MCP config: { "url": "http://localhost:${state.port}/mcp" }`
          },
          activeSessions: Object.keys(transports).length
        })
      )
      return
    }

    // 404 for unknown routes
    res.writeHead(404, { "Content-Type": "application/json" })
    res.end(JSON.stringify({ error: "Not found" }))
  })

  // Try to start the server, incrementing port if busy
  const startWithRetry = (port: number, maxRetries: number = 10): Promise<number> => {
    return new Promise((resolve, reject) => {
      state.httpServer!.once("error", (err: NodeJS.ErrnoException) => {
        if (err.code === "EADDRINUSE" && maxRetries > 0) {
          resolve(startWithRetry(port + 1, maxRetries - 1))
        } else {
          reject(err)
        }
      })

      state.httpServer!.listen(port, "127.0.0.1", () => {
        resolve(port)
      })
    })
  }

  try {
    const actualPort = await startWithRetry(state.port)
    state.port = actualPort
    state.isRunning = true

    // Show notification to user
    window.showInformationMessage(
      `🔌 ABAP MCP Server running on port ${actualPort}. External AI clients can connect to http://localhost:${actualPort}/mcp`
    )
  } catch (error) {
    throw error
  }
}

function stopServer(): void {
  // Close all active transports
  for (const sessionId of Object.keys(transports)) {
    try {
      transports[sessionId].close()
      delete transports[sessionId]
    } catch {
      // Ignore errors during cleanup
    }
  }

  if (state.httpServer) {
    state.httpServer.close()
    state.httpServer = null
  }
  state.isRunning = false
}

// ============================================================================
// PUBLIC API
// ============================================================================

/**
 * Initialize and start the MCP server based on settings
 * Call this from extension.ts during activation
 */

const MCP_COPILOT_DISMISSED_KEY = "abapfs.mcpServer.copilotPromptDismissed"

/**
 * Start MCP server via command. Shows Copilot warning if applicable.
 */
export async function startMcpServerCommand(context: vscode.ExtensionContext): Promise<void> {
  if (state.isRunning) {
    window.showInformationMessage(`MCP Server is already running on port ${state.port}.`)
    return
  }

  // One-time check: if LLM models are available (Copilot active), user may not need MCP
  const dismissed = context.globalState.get<boolean>(MCP_COPILOT_DISMISSED_KEY)
  if (!dismissed) {
    let hasModels = false
    try {
      const models = await vscode.lm.selectChatModels({})
      hasModels = models.length > 0
    } catch {
      // No models available — user likely needs MCP for external AI clients
    }

    if (hasModels) {
      const selection = await vscode.window.showQuickPick(
        [
          {
            label: "$(rocket) Start MCP Anyway",
            description: "I use Cursor/Claude/other external AI tools",
            value: "start"
          },
          {
            label: "$(x) Don't Start",
            description: "I only use GitHub Copilot — don't need MCP",
            value: "disable"
          }
        ],
        {
          placeHolder:
            "Github Copilot AI models detected. MCP server is for external AI tools — do you still need it?",
          ignoreFocusOut: true
        }
      )

      if (!selection || selection.value === "disable") {
        await context.globalState.update(MCP_COPILOT_DISMISSED_KEY, true)
        const config = vscode.workspace.getConfiguration("abapfs.mcpServer")
        await config.update("autoStart", false, vscode.ConfigurationTarget.Workspace)
        log("🔌 MCP Server disabled by user — Copilot provides native tool access")
        return
      }
      // "start" selected
      await context.globalState.update(MCP_COPILOT_DISMISSED_KEY, true)
    }
  }

  // Persist autoStart so MCP starts automatically on next VS Code launch
  if (vscode.workspace.workspaceFolders?.length) {
    const mcpConfig = vscode.workspace.getConfiguration("abapfs.mcpServer")
    await mcpConfig.update("autoStart", true, vscode.ConfigurationTarget.Workspace)
  } else {
    window.showInformationMessage(
      "MCP Server started for this session. Open a workspace/folder and start MCP to persist this setting in that workspace across restarts."
    )
  }

  try {
    await startHttpServer()
    context.subscriptions.push({
      dispose: () => {
        stopServer()
      }
    })
  } catch (error) {
    window.showWarningMessage(
      `MCP Server failed to start: ${error instanceof Error ? error.message : String(error)}`
    )
  }
}

export async function initializeMcpServer(context: vscode.ExtensionContext): Promise<void> {
  const settings = getMcpSettings()

  if (!settings.autoStart) {
    return // Don't start if autoStart is disabled
  }

  // On autoStart, reuse the same logic (modal + start)
  await startMcpServerCommand(context)
}

/**
 * Get the current MCP server status
 */
export function getMcpServerStatus(): { isRunning: boolean; port: number; url: string } {
  return {
    isRunning: state.isRunning,
    port: state.port,
    url: state.isRunning ? `http://localhost:${state.port}/mcp` : ""
  }
}
